# Official web snapshot: Thresholds 2026

- URL: https://dhhp.edu.vn/post/thong-bao-ve-nguong-bao-dam-chat-luong-dau-vao-quy-tac-quy-doi-tuong-duong-diem-xet-tuyen-giua-cac-phuong-thuc-xet-tuyen-dai-hoc-chinh-quy-nam-2026-73810.html
- Publication date: 10/07/2026
- Snapshot date: 2026-07-26

| Mã | Chương trình | Ngưỡng PT1 | Điều kiện bổ sung |
|---|---|---:|---|
| 731010120 | Kinh tế: Logistics và vận tải đa phương thức (CLC) | 18.00 |  |
| 734010120 | Quản trị kinh doanh: Kinh doanh số và đổi mới sáng tạo (CLC) | 17.50 |  |
| 734010121 | Quản trị kinh doanh: Quản trị kinh doanh quốc tế (CLC) | 17.50 |  |
| 734030120 | Kế toán: Kế toán doanh nghiệp theo định hướng ACCA (CLC) | 17.50 |  |
| 748020120 | Công nghệ thông tin: Thiết kế game và Multimedia (CLC) | 17.50 |  |
| 751030120 | Công nghệ kỹ thuật điện, điện tử: Công nghệ điện tử, vi mạch và bán dẫn (CLC) | 17.50 |  |
| 738010101 | Luật | 20.00 | Điểm Toán >= 6 hoặc Ngữ văn >= 6 hoặc tổng điểm Toán + Ngữ văn >= 12. |
| 734010101 | Quản trị kinh doanh | 17.00 |  |
| 734010102 | Quản trị tài chính kế toán | 17.00 |  |
| 734011501 | Marketing số | 17.00 |  |
| 734011502 | Marketing | 17.00 |  |
| 734011503 | Truyền thông marketing | 17.00 |  |
| 734012201 | Thương mại điện tử | 17.00 |  |
| 734020102 | Tài chính doanh nghiệp | 17.00 |  |
| 734030102 | Kế toán doanh nghiệp | 17.00 |  |
| 734030103 | Kế toán - Kiểm toán | 17.00 |  |
| 722020101 | Ngôn ngữ Anh | 17.50 | Điểm môn Ngoại ngữ trong tổ hợp xét tuyển >= 6,0. |
| 722020401 | Ngôn ngữ Trung Quốc | 17.50 |  |
| 722903001 | VÄƒn há»c | 17.00 |  |
| 731010102 | Kinh tế ngoại thương | 17.00 |  |
| 731010103 | Quản lý kinh tế | 17.00 |  |
| 731010104 | Logistics và vận tải đa phương thức | 18.00 |  |
| 731040101 | Tâm lý học giáo dục | 17.00 |  |
| 731060801 | Nhật Bản học | 17.00 |  |
| 776010101 | Công tác xã hội | 17.00 |  |
| 781010301 | Quản trị dịch vụ du lịch và lữ hành | 17.50 |  |
| 781010302 | Quản trị lữ hành, khách sạn | 17.00 |  |
| 781010303 | Hướng dẫn du lịch | 17.00 |  |
| 748020101 | Công nghệ thông tin | 17.00 |  |
| 748020102 | TrÃ­ tuá»‡ nhÃ¢n táº¡o vÃ  Khoa há»c dá»¯ liá»‡u | 17.00 |  |
| 751010302 | Xây dựng dân dụng và công nghiệp | 16.50 |  |
| 751020201 | Công nghệ chế tạo máy | 16.50 |  |
| 751020301 | Công nghệ kỹ thuật cơ điện tử | 17.00 |  |
| 751030102 | Äiá»‡n cÃ´ng nghiá»‡p vÃ  dÃ¢n dá»¥ng | 16.50 |  |
| 751030302 | Äiá»‡n tá»± Ä‘á»™ng cÃ´ng nghiá»‡p | 16.50 |  |
| 758010101 | Kiến trúc | 16.50 | Với tổ hợp V01, tổng điểm 02 môn văn hóa + điểm ưu tiên >= 11,00. |
| 714020101 | Giáo dục Mầm non | 20.00 | Tổng điểm 02 môn văn hóa + điểm ưu tiên >= 13,33. |
| 714020201 | GiÃ¡o dá»¥c Tiá»ƒu há»c | 20.00 |  |
| 714020601 | Giáo dục Thể chất | 19.00 | Tổng điểm 02 môn văn hóa + điểm ưu tiên >= 12,67. |
| 714020901 | Sư phạm Toán học | 20.00 |  |
| 714021701 | Sư phạm Ngữ văn | 20.00 |  |
| 714023101 | Sư phạm Tiếng Anh | 20.00 | Điểm môn Ngoại ngữ trong tổ hợp xét tuyển >= 6,0. |
