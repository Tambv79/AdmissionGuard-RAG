# Official portal news index snapshot
- Admissions portal: https://tuyensinh.dhhp.edu.vn/
- News: https://tuyensinh.dhhp.edu.vn/news
- University portal: https://dhhp.edu.vn/
- Snapshot date: 2026-07-26

The official portals list the 2026 admissions notice, admissions information, current programs,
threshold/equivalence notice, aptitude-exam notice, and foreign-language certificate notice.
