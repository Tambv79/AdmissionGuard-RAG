# Official live web snapshot: Programs 2026

- URL: https://tuyensinh.dhhp.edu.vn/article/nganh-chuyen-nganh-chuong-trinh-tuyen-sinh-dai-hoc-chinh-quy-nam-2026
- Snapshot date: 2026-07-26
- Current total quota: **3,195**

| Mã | Chương trình | Phương thức | Tổ hợp | Phạm vi chỉ tiêu | Chỉ tiêu |
|---|---|---|---|---|---:|
| 7310101.20 | Kinh tế: Logistics và vận tải đa phương thức (CLC) | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | program | 50 |
| 7340101.20 | Quản trị kinh doanh: Kinh doanh số và đổi mới sáng tạo (CLC) | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | program | 50 |
| 7340101.21 | Quản trị kinh doanh: Quản trị kinh doanh quốc tế (CLC) | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | program | 50 |
| 7340301.20 | Kế toán: Kế toán doanh nghiệp theo định hướng ACCA (CLC) | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C02, D01, D07 | program | 50 |
| 7480201.20 | Công nghệ thông tin: Thiết kế game và Multimedia (CLC) | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C02, D01, X26 | program | 50 |
| 7510301.20 | Công nghệ kỹ thuật điện, điện tử: Công nghệ điện tử, vi mạch và bán dẫn (CLC) | PT1, PT2, PT3, PT4, PT5 | A00, A01, A02, A10, C01, D01 | program | 50 |
| 7380101.01 | Luật | PT1, PT2, PT3, PT4, PT5 | A00, C03, C04, D01, X01 | program | 70 |
| 7340101.01 | Quản trị kinh doanh | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | major_group | Nhóm 100 |
| 7340101.02 | Quản trị tài chính kế toán | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | major_group | Nhóm 100 |
| 7340115.01 | Marketing số | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | major_group | Nhóm 200 |
| 7340115.02 | Marketing | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | major_group | Nhóm 200 |
| 7340115.03 | Truyền thông marketing | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | major_group | Nhóm 200 |
| 7340122.01 | Thương mại điện tử | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | program | 110 |
| 7340201.02 | Tài chính doanh nghiệp | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C02, D01, D07 | major_group | Nhóm 125 |
| 7340301.02 | Kế toán doanh nghiệp | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C02, D01, D07 | major_group | Nhóm 150 |
| 7340301.03 | Kế toán - Kiểm toán | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C02, D01, D07 | major_group | Nhóm 150 |
| 7220201.01 | Ngôn ngữ Anh | PT1, PT3.1, PT5 | D01, D09, D10, D14, D15 | program | 145 |
| 7220204.01 | Ngôn ngữ Trung Quốc | PT1, PT3.1, PT5 | D01, D04, D09, D14, D15, D45 | program | 145 |
| 7229030.01 | VÄƒn há»c | PT1, PT2, PT3, PT4, PT5 | C00, C03, C04, C19, C20, D15 | program | 60 |
| 7310101.02 | Kinh tế ngoại thương | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | major_group | Nhóm 150 |
| 7310101.03 | Quản lý kinh tế | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | major_group | Nhóm 150 |
| 7310101.04 | Logistics và vận tải đa phương thức | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C03, C04, D01 | major_group | Nhóm 150 |
| 7310401.01 | Tâm lý học giáo dục | PT1, PT2, PT3, PT4, PT5 | C00, C03, C04, D01, D15, X01 | major_group | Nhóm 50 |
| 7310608.01 | Nhật Bản học | PT1, PT3.1, PT5 | C00, D01, D04, D06, DD2 | major_group | Nhóm 50 |
| 7760101.01 | Công tác xã hội | PT1, PT2, PT3, PT4, PT5 | C00, C03, C04, D01, D15, X01 | program | 65 |
| 7810103.01 | Quản trị dịch vụ du lịch và lữ hành | PT1, PT2, PT3, PT4, PT5 | C00, C03, C04, D01, D14, D15 | major_group | Nhóm 210 |
| 7810103.02 | Quản trị lữ hành, khách sạn | PT1, PT2, PT3, PT4, PT5 | C00, C03, C04, D01, D14, D15 | major_group | Nhóm 210 |
| 7810103.03 | Hướng dẫn du lịch | PT1, PT2, PT3, PT4, PT5 | C00, C03, C04, D01, D14, D15 | major_group | Nhóm 210 |
| 7480201.01 | Công nghệ thông tin | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C02, D01, X26 | major_group | Nhóm 135 |
| 7480201.02 | TrÃ­ tuá»‡ nhÃ¢n táº¡o vÃ  Khoa há»c dá»¯ liá»‡u | PT1, PT2, PT3, PT4, PT5 | A00, A01, C01, C02, D01, X26 | major_group | Nhóm 135 |
| 7510103.02 | Xây dựng dân dụng và công nghiệp | PT1, PT2, PT3, PT4, PT5 | A00, A01, A02, A10, C01, D01 | major_group | Nhóm 70 |
| 7510202.01 | Công nghệ chế tạo máy | PT1, PT2, PT3, PT4, PT5 | A00, A01, A02, A10, C01, D01 | program | 60 |
| 7510203.01 | Công nghệ kỹ thuật cơ điện tử | PT1, PT2, PT3, PT4, PT5 | A00, A01, A02, A10, C01, D01 | program | 110 |
| 7510301.02 | Äiá»‡n cÃ´ng nghiá»‡p vÃ  dÃ¢n dá»¥ng | PT1, PT2, PT3, PT4, PT5 | A00, A01, A02, A10, C01, D01 | major_group | Nhóm 65 |
| 7510303.02 | Äiá»‡n tá»± Ä‘á»™ng cÃ´ng nghiá»‡p | PT1, PT2, PT3, PT4, PT5 | A00, A01, A02, A10, C01, D01 | major_group | Nhóm 120 |
| 7580101.01 | Kiến trúc | PT1, PT2, PT3, PT4, PT5 | A00, A01, D01, V01 | program | 55 |
| 7140201.01 | Giáo dục Mầm non | PT1, PT3.1, PT5 | M00, M01, M02, M03, M04 | program | 120 |
| 7140202.01 | GiÃ¡o dá»¥c Tiá»ƒu há»c | PT1, PT3.1, PT5 | A01, C01, C02, C03, C04, D01 | program | 150 |
| 7140206.01 | Giáo dục Thể chất | PT1, PT2, PT5 | T00, T01, T02 | program | 40 |
| 7140209.01 | Sư phạm Toán học | PT1, PT3.1, PT5 | A00, A01, C01, C02, D07 | program | 110 |
| 7140217.01 | Sư phạm Ngữ văn | PT1, PT3.1, PT5 | C00, C03, C04, D01, D14, D15 | program | 110 |
| 7140231.01 | Sư phạm Tiếng Anh | PT1, PT3.1, PT5 | D01, D09, D10, D14, D15 | program | 120 |
