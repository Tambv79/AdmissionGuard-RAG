# Erratum: DHHP-Admission-Corpus-v1.0.1

Parent corpus: DHHP-Admission-Corpus-v1.0  
Snapshot date retained: 2026-07-26  
Patch type: encoding and retrieval-completeness correction.

## Problems found before Step 2.2
- Một số chuỗi tiếng Việt trong current_facts và active Markdown bị lỗi mojibake.
- Active knowledge chưa biểu diễn đầy đủ bảng quy đổi IELTS mặc dù fact đã có trong nguồn cấu trúc và Thông báo 1889.

## Corrections
- Sửa mã hóa tiếng Việt trong JSON, CSV, Markdown và web snapshots.
- Tái tạo 09 active knowledge files bằng UTF-8 chuẩn.
- Bổ sung bảng quy đổi IELTS vào 06_certificate_status.md.

## Scientific impact
Không thay đổi nguồn, ngày snapshot, chỉ tiêu, phương thức, ngưỡng, thời hạn hoặc chính sách ưu tiên nguồn. Corpus v1.0 không được dùng để nạp vector store; mọi thí nghiệm bắt đầu từ v1.0.1.
