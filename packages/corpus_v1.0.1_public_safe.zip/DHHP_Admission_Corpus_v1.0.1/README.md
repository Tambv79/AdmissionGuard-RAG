# DHHP-Admission-Corpus-v1.0

Status: PASS_CORPUS_V1_0_FROZEN_WITH_FIELD_LEVEL_TEMPORAL_PRECEDENCE  
Snapshot date: 2026-07-26  
Scope: Tuyển sinh đại học chính quy năm 2026.

## Dùng cho vector store
Chỉ upload các tệp được liệt kê trong ACTIVE_VECTOR_STORE_UPLOAD_LIST.txt.

## Không upload
- raw_sources/
- archive_repaired_legacy/
- structured/superseded_facts.csv
- báo cáo, workbook và tệp QA

## Quy tắc
Không thay đổi bất kỳ tệp active nào trong cùng một đợt thực nghiệm. Khi có nguồn mới,
tạo phiên bản corpus mới thay vì ghi đè v1.0.
