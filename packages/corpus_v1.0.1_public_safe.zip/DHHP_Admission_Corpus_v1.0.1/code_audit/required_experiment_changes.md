# Required changes
1. Return experiment response object with answer, retrieval results, citations, usage, latency and model.
2. Include and parse file_search results.
3. Attach doc_id, source_date, admission_year, topic, status and snapshot_date.
4. Disable cache for benchmark runs.
5. Log raw responses and checksums.
6. Exclude legacy archive and superseded facts from active vector store.
7. Enforce evidence-bounded responses for grouped quotas.
