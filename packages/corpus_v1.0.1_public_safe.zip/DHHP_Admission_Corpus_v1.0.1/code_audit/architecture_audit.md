# Static architecture audit
IIS package SHA-256: 9d1c804eb08459485ee4446e7e5f6c32505b3472a3c3eb0cb89ac884e2687426
Legacy package SHA-256: 6992f35da2ce6669bb516644a0fa3b820a4e29c1994e21ce471a397986b4f0ee

## Positive
- Complete .NET 8 solution.
- Uses OpenAI Responses API file_search with a vector store.
- TopK configurable 1-10.
- API key/vector store externalized.
- CORS, rate limit, input validation and health endpoint included.

## Limitations
- Returns only answer text; retrieved text, score, file ID and citations are not persisted.
- Recall@k, MRR, nDCG and citation metrics cannot be calculated.
- Uploader lacks stable document attributes and explicit chunking strategy.
- Cache is enabled by default and must be disabled for experiments.
- Model/version, usage, latency and cost are not logged per run.
- DailyRequestLimit is configured but not enforced.
- Feedback endpoint stores question/answer content.
- Active knowledge corpus was absent from the IIS package.
