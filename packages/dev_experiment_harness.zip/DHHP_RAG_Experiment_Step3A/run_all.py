from pathlib import Path
import subprocess, sys, os
ROOT=Path(__file__).resolve().parents[0]
def run(args):
    print('\n>>>',' '.join(args)); subprocess.run([sys.executable,*args],cwd=ROOT,check=True)
if __name__=='__main__':
    live='--live' in sys.argv
    run(['scripts/selftest.py']); run(['scripts/00_preflight.py']+(['--live'] if live else [])); run(['scripts/01_prepare_chunks.py'])
    run(['scripts/02_run_retrieval_screen.py']+(['--live'] if live else []))
    if live: run(['scripts/03_run_generation_screen.py'])
    run(['scripts/04_finalize.py'])
