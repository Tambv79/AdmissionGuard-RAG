from pathlib import Path
import sys, json
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.chunking import split_markdown
from src.retrieval import BM25, token_f1, metrics_for_ranked

def main():
    text='# A\nHotline 0398.171.171.\n# B\nNgành Công nghệ thông tin có mã 748020101.'
    chunks=split_markdown(text,8,2); assert len(chunks)>=2
    cs=[{'chunk_id':str(i),'filename':'x.md','text':c['text']} for i,c in enumerate(chunks)]
    rank=BM25(cs).score('hotline tuyển sinh'); assert '0398' in cs[rank[0][0]]['text']
    assert token_f1('hotline 0398','hotline 0398')==1.0
    ev=[{'document_id':'normalized/x.md','evidence_text':'Hotline 0398.171.171.'}]
    m=metrics_for_ranked(cs,rank,ev); assert m['hit_at_3']==1
    print(json.dumps({'status':'PASS','note':'Synthetic engineering QA only; not scientific evidence.'},indent=2))
if __name__=='__main__': main()
