from __future__ import annotations

from pathlib import Path
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.common import CONFIG, append_jsonl, load_jsonl
from src.metrics import generation_metrics
from src.openai_api import rerank, response_call
from src.retrieval import BM25, dense_rank, rrf

BASE_INSTRUCTIONS = """You answer Vietnamese university-admission questions. Use only the supplied context. Cite every factual answer using the provided [CHUNK_ID]. If the context is insufficient, state that the official corpus does not publish the requested information. Do not predict admission outcomes."""

FULL_INSTRUCTIONS = """You are a controlled Vietnamese university-admission assistant. Use only the supplied context and the field-level temporal policy. Prefer current facts, explicitly correct superseded premises, cite every factual claim as [CHUNK_ID], refuse forecasts and unsupported values, and ask one concise clarification when personal information is insufficient. Never infer a child-program quota from a group quota."""

CONFIGURATIONS = [
    "C0_LLM_ONLY",
    "C1_BM25",
    "C2_DENSE",
    "C3_HYBRID",
    "C4_HYBRID_RERANK",
    "C5_FULL",
]


def context_text(chunks: list[dict]) -> str:
    return "\n\n".join(
        f"[{chunk['chunk_id']}] SOURCE={chunk['filename']} "
        f"L{chunk['line_start']}-L{chunk['line_end']}\n{chunk['text']}"
        for chunk in chunks
    )


def load_vectors(path: Path) -> list[list[float]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return payload["vectors"] if isinstance(payload, dict) else payload


def load_rerank_cache(path: Path) -> dict[str, dict]:
    cache = {}
    for row in load_jsonl(path):
        cache[row["cache_key"]] = row
    return cache


def main() -> int:
    items = load_jsonl(ROOT / "benchmark" / "DEV_GOLD_v1.0.jsonl")
    retrieval_summary_path = ROOT / "outputs" / "retrieval_summary_live.json"
    if not retrieval_summary_path.exists():
        raise RuntimeError("Live retrieval summary is missing. Run scripts/02_run_retrieval_screen.py --live first.")
    summary = json.loads(retrieval_summary_path.read_text(encoding="utf-8"))
    best = {
        method: next(row for row in summary if row["method"] == method)
        for method in ("bm25", "dense", "hybrid_rrf")
    }

    chunksets: dict[str, list[dict]] = {}
    bm25_models: dict[str, BM25] = {}
    vector_sets: dict[str, list[list[float]]] = {}
    model_slug = CONFIG["embedding_model"].replace("/", "_")
    for selection in best.values():
        chunk_config_id = selection["chunk_config_id"]
        if chunk_config_id in chunksets:
            continue
        chunks = load_jsonl(ROOT / "state" / "chunks" / chunk_config_id / "chunks.jsonl")
        chunksets[chunk_config_id] = chunks
        bm25_models[chunk_config_id] = BM25(chunks)
        vector_sets[chunk_config_id] = load_vectors(
            ROOT / "state" / "retrieval" / f"{chunk_config_id}__{model_slug}.json"
        )
    query_vectors = load_vectors(ROOT / "state" / "retrieval" / f"queries__{model_slug}.json")

    output_path = ROOT / "outputs" / "generation_results.jsonl"
    completed = {
        (row["item_id"], row["configuration_id"])
        for row in load_jsonl(output_path)
    }
    rerank_cache_path = ROOT / "state" / "rerank_cache.jsonl"
    rerank_cache = load_rerank_cache(rerank_cache_path)

    for query_index, item in enumerate(items):
        item_id = item["item_id"]
        rank_cache: dict[str, tuple[list[tuple[int, float]], float, str]] = {}

        for configuration_id in CONFIGURATIONS:
            if (item_id, configuration_id) in completed:
                continue

            retrieved: list[dict] = []
            retrieval_latency_ms = 0.0
            rerank_metadata = None
            selected_chunk_config = None

            if configuration_id != "C0_LLM_ONLY":
                method = {
                    "C1_BM25": "bm25",
                    "C2_DENSE": "dense",
                    "C3_HYBRID": "hybrid_rrf",
                    "C4_HYBRID_RERANK": "hybrid_rrf",
                    "C5_FULL": "hybrid_rrf",
                }[configuration_id]
                selected_chunk_config = best[method]["chunk_config_id"]
                chunks = chunksets[selected_chunk_config]

                if method not in rank_cache:
                    started = time.perf_counter()
                    bm25_rank = bm25_models[selected_chunk_config].score(item["question_text_vi"])
                    if method == "bm25":
                        ranked = bm25_rank
                    else:
                        dense = dense_rank(
                            chunks,
                            vector_sets[selected_chunk_config],
                            query_vectors[query_index],
                        )
                        ranked = (
                            dense
                            if method == "dense"
                            else rrf(chunks, bm25_rank, dense, CONFIG["rrf_k"])
                        )
                    elapsed = (time.perf_counter() - started) * 1000
                    rank_cache[method] = (ranked, elapsed, selected_chunk_config)
                ranked, retrieval_latency_ms, _ = rank_cache[method]
                candidates = [
                    chunks[index]
                    for index, _ in ranked[: int(CONFIG["rerank_candidate_k"])]
                ]

                if configuration_id in ("C4_HYBRID_RERANK", "C5_FULL"):
                    cache_key = f"{item_id}|{selected_chunk_config}"
                    if cache_key not in rerank_cache:
                        ordering, rerank_result = rerank(item["question_text_vi"], candidates)
                        cache_row = {
                            "cache_key": cache_key,
                            "item_id": item_id,
                            "chunk_config_id": selected_chunk_config,
                            "ordering": ordering,
                            "latency_ms": rerank_result["latency_ms"],
                            "usage": rerank_result["usage"],
                            "model": rerank_result["model"],
                            "response_id": rerank_result.get("response_id"),
                        }
                        append_jsonl(rerank_cache_path, cache_row)
                        rerank_cache[cache_key] = cache_row
                    cached = rerank_cache[cache_key]
                    candidate_map = {candidate["chunk_id"]: candidate for candidate in candidates}
                    candidates = [
                        candidate_map[chunk_id]
                        for chunk_id in cached["ordering"]
                        if chunk_id in candidate_map
                    ]
                    rerank_metadata = {
                        "latency_ms": cached["latency_ms"],
                        "usage": cached["usage"],
                        "model": cached["model"],
                        "response_id": cached.get("response_id"),
                        "cache_key": cache_key,
                    }
                retrieved = candidates[:5]

            if configuration_id == "C0_LLM_ONLY":
                user_input = item["question_text_vi"]
                instructions = (
                    "Answer the Vietnamese question concisely. Do not claim access to institutional documents. "
                    "Do not invent unpublished values or predict admission outcomes."
                )
            else:
                user_input = (
                    f"QUESTION:\n{item['question_text_vi']}\n\n"
                    f"CONTEXT:\n{context_text(retrieved)}"
                )
                instructions = FULL_INSTRUCTIONS if configuration_id == "C5_FULL" else BASE_INSTRUCTIONS

            response = response_call(instructions, user_input, call_type="generation")
            row = {
                "item_id": item_id,
                "configuration_id": configuration_id,
                "question": item["question_text_vi"],
                "answer": response["answer"],
                "chunk_config_id": selected_chunk_config,
                "retrieved_chunks": [
                    {
                        "chunk_id": chunk["chunk_id"],
                        "filename": chunk["filename"],
                        "line_start": chunk["line_start"],
                        "line_end": chunk["line_end"],
                        "text": chunk["text"],
                    }
                    for chunk in retrieved
                ],
                "retrieval_latency_ms": retrieval_latency_ms,
                "generation_latency_ms": response["latency_ms"],
                "rerank": rerank_metadata,
                "usage": response["usage"],
                "model": response["model"],
                "response_id": response.get("response_id"),
                "metrics_proxy": generation_metrics(
                    item,
                    response["answer"],
                    [chunk["chunk_id"] for chunk in retrieved],
                ),
                "raw_response": response["raw"],
            }
            append_jsonl(output_path, row)
            completed.add((item_id, configuration_id))

    completed_rows = load_jsonl(output_path)
    expected = len(items) * len(CONFIGURATIONS)
    status = "PASS" if len(completed_rows) == expected else "PARTIAL"
    print(
        json.dumps(
            {
                "status": status,
                "output": str(output_path),
                "completed_pairs": len(completed_rows),
                "expected_pairs": expected,
                "rerank_cache_entries": len(load_jsonl(rerank_cache_path)),
            },
            indent=2,
        )
    )
    return 0 if status == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
