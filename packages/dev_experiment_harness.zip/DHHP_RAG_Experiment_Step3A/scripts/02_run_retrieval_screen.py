from __future__ import annotations

from pathlib import Path
import json
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.common import CONFIG, load_jsonl, read_csv
from src.openai_api import embed
from src.retrieval import BM25, dense_rank, metrics_for_ranked, rrf


def load_vector_cache(path: Path) -> list[list[float]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return payload["vectors"] if isinstance(payload, dict) else payload


def save_vector_cache(path: Path, vectors: list[list[float]], model: str, source_count: int) -> None:
    path.write_text(
        json.dumps(
            {
                "model": model,
                "source_count": source_count,
                "vectors": vectors,
            }
        ),
        encoding="utf-8",
    )


def main(live: bool = False) -> int:
    items = load_jsonl(ROOT / "benchmark" / "DEV_GOLD_v1.0.jsonl")
    evidence = read_csv(ROOT / "benchmark" / "DEV_GOLD_EVIDENCE_v1.0.csv")
    evidence_map = {item["item_id"]: [] for item in items}
    for span in evidence:
        # Retrieval is scored only against evidence units available in the active indexed corpus.
        # Structured/PDF provenance remains part of generation and temporal validation, but is not retrievable here.
        if span.get("source_type") == "NORMALIZED_CORPUS":
            evidence_map.setdefault(span["item_id"], []).append(span)

    rows_out: list[dict] = []
    state = ROOT / "state" / "retrieval"
    state.mkdir(parents=True, exist_ok=True)
    model_slug = CONFIG["embedding_model"].replace("/", "_")

    query_vectors = None
    if live:
        query_cache = state / f"queries__{model_slug}.json"
        if query_cache.exists():
            query_vectors = load_vector_cache(query_cache)
        else:
            query_vectors = []
            for start in range(0, len(items), 64):
                vectors, _ = embed([item["question_text_vi"] for item in items[start : start + 64]])
                query_vectors.extend(vectors)
            save_vector_cache(query_cache, query_vectors, CONFIG["embedding_model"], len(items))

    for cfg in CONFIG["chunk_configs"]:
        chunks = load_jsonl(ROOT / "state" / "chunks" / cfg["id"] / "chunks.jsonl")
        bm25 = BM25(chunks)
        chunk_vectors = None
        if live:
            chunk_cache = state / f"{cfg['id']}__{model_slug}.json"
            if chunk_cache.exists():
                chunk_vectors = load_vector_cache(chunk_cache)
            else:
                chunk_vectors = []
                for start in range(0, len(chunks), 64):
                    vectors, _ = embed([chunk["text"] for chunk in chunks[start : start + 64]])
                    chunk_vectors.extend(vectors)
                save_vector_cache(chunk_cache, chunk_vectors, CONFIG["embedding_model"], len(chunks))

        for query_index, item in enumerate(items):
            started = time.perf_counter()
            bm25_rank = bm25.score(item["question_text_vi"])
            bm25_ms = (time.perf_counter() - started) * 1000
            ranks = {"bm25": (bm25_rank, bm25_ms)}

            if live:
                started = time.perf_counter()
                dense = dense_rank(chunks, chunk_vectors, query_vectors[query_index])
                dense_ms = (time.perf_counter() - started) * 1000
                hybrid = rrf(chunks, bm25_rank, dense, CONFIG["rrf_k"])
                ranks.update(
                    {
                        "dense": (dense, dense_ms),
                        "hybrid_rrf": (hybrid, bm25_ms + dense_ms),
                    }
                )

            for method, (ranked, latency_ms) in ranks.items():
                metrics = metrics_for_ranked(
                    chunks,
                    ranked,
                    evidence_map[item["item_id"]],
                    ks=CONFIG["top_k_values"],
                )
                rows_out.append(
                    {
                        "item_id": item["item_id"],
                        "chunk_config_id": cfg["id"],
                        "method": method,
                        "latency_ms": latency_ms,
                        **metrics,
                        "ranked_chunk_ids": [chunks[index]["chunk_id"] for index, _ in ranked[:15]],
                    }
                )

    output_name = "retrieval_screen_live.jsonl" if live else "retrieval_screen_bm25_local.jsonl"
    (ROOT / "outputs" / output_name).write_text(
        "\n".join(json.dumps(row, ensure_ascii=False) for row in rows_out) + "\n",
        encoding="utf-8",
    )

    grouped: dict[tuple[str, str], list[dict]] = {}
    for row in rows_out:
        grouped.setdefault((row["chunk_config_id"], row["method"]), []).append(row)
    summary = []
    for (chunk_config_id, method), rows in grouped.items():
        summary.append(
            {
                "chunk_config_id": chunk_config_id,
                "method": method,
                "n": len(rows),
                "macro_ndcg_at_5": statistics.mean(row["ndcg_at_5"] for row in rows),
                "macro_evidence_recall_at_5": statistics.mean(
                    row["evidence_recall_at_5"] for row in rows
                ),
                "macro_mrr": statistics.mean(row["mrr"] for row in rows),
                "mean_retrieval_latency_ms": statistics.mean(row["latency_ms"] for row in rows),
            }
        )
    summary.sort(
        key=lambda row: (
            -row["macro_ndcg_at_5"],
            -row["macro_evidence_recall_at_5"],
            -row["macro_mrr"],
            row["mean_retrieval_latency_ms"],
        )
    )
    summary_name = "retrieval_summary_live.json" if live else "retrieval_summary_bm25_local.json"
    (ROOT / "outputs" / summary_name).write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({"status": "PASS", "live": live, "rows": len(rows_out), "summary": summary}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main("--live" in sys.argv))
