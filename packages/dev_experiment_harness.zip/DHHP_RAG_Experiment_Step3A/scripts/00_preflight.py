from __future__ import annotations

from pathlib import Path
import json
import os
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.common import CONFIG, lexical_tokens, load_jsonl, read_csv


def estimate_live_plan(items: list[dict], corpus_files: list[Path]) -> dict:
    question_lexical = sum(len(lexical_tokens(item["question_text_vi"])) for item in items)
    corpus_lexical = sum(len(lexical_tokens(path.read_text(encoding="utf-8"))) for path in corpus_files)
    n = len(items)
    max_chunk = max(int(cfg["max_lexical_tokens"]) for cfg in CONFIG["chunk_configs"])
    context_chunks = 5
    # Conservative lexical-token-to-model-token multiplier for Vietnamese/mixed identifiers.
    factor = 1.45
    instruction_allowance = 180
    generation_input = factor * (
        question_lexical  # C0
        + 5 * question_lexical  # C1-C5 questions
        + n * 5 * (context_chunks * max_chunk + instruction_allowance)
    )
    generation_output = n * 6 * int(CONFIG["max_output_tokens"])
    # One rerank call per item; C4 and C5 share the result.
    rerank_input = factor * n * (
        int(CONFIG["rerank_candidate_k"]) * min(max_chunk, 450) + 220
    )
    rerank_output = n * 500
    # Three chunk configurations plus one question embedding cache.
    embedding_input = factor * (3 * corpus_lexical * 1.35 + question_lexical)

    pricing = CONFIG["pricing_snapshot"]
    estimated_usd = (
        (generation_input + rerank_input) / 1_000_000 * float(pricing["generator_input_per_million_usd"])
        + (generation_output + rerank_output) / 1_000_000 * float(pricing["generator_output_per_million_usd"])
        + embedding_input / 1_000_000 * float(pricing["embedding_input_per_million_usd"])
    )
    planned_requests = 2 + 4 + n + n * 6  # model checks + embedding batches + rerank + generation
    return {
        "planned_requests_without_retries": planned_requests,
        "conservative_input_tokens": round(generation_input + rerank_input),
        "conservative_output_tokens": round(generation_output + rerank_output),
        "conservative_embedding_tokens": round(embedding_input),
        "conservative_estimated_usd": round(estimated_usd, 4),
        "authorized_request_ceiling": int(CONFIG["cost_guard"]["max_live_requests"]),
        "authorized_cost_ceiling_usd": float(CONFIG["cost_guard"]["max_estimated_usd"]),
    }


def main(live: bool = False) -> int:
    errors: list[str] = []
    notes: list[str] = []
    corpus_files = sorted((ROOT / "corpus" / "normalized").glob("*.md"))
    if len(corpus_files) != 9:
        errors.append(f"Expected 9 corpus files, found {len(corpus_files)}")

    items = load_jsonl(ROOT / "benchmark" / "DEV_GOLD_v1.0.jsonl")
    claims = read_csv(ROOT / "benchmark" / "DEV_GOLD_CLAIMS_v1.0.csv")
    evidence = read_csv(ROOT / "benchmark" / "DEV_GOLD_EVIDENCE_v1.0.csv")
    if len(items) != 60:
        errors.append(f"Expected 60 DEV items, found {len(items)}")
    if len(claims) != 127:
        errors.append(f"Expected 127 claims, found {len(claims)}")
    if len(evidence) != 89:
        errors.append(f"Expected 89 evidence spans, found {len(evidence)}")
    if any(item.get("gold_status") != "LOCKED_GOLD" for item in items):
        errors.append("Not all items are LOCKED_GOLD")

    estimate = estimate_live_plan(items, corpus_files)
    if estimate["planned_requests_without_retries"] > estimate["authorized_request_ceiling"]:
        errors.append("Planned request count exceeds the authorized request ceiling.")
    if estimate["conservative_estimated_usd"] > estimate["authorized_cost_ceiling_usd"]:
        errors.append("Conservative estimated cost exceeds the authorized cost ceiling.")

    if live:
        if not os.environ.get("OPENAI_API_KEY", "").strip():
            errors.append("OPENAI_API_KEY is missing")
        guard = CONFIG["cost_guard"]
        if os.environ.get(guard["require_env"]) != guard["required_value"]:
            errors.append(f"{guard['require_env']} must equal {guard['required_value']}")
        if not errors:
            from src.openai_api import verify_model

            for model in (CONFIG["generator_model"], CONFIG["embedding_model"]):
                try:
                    metadata = verify_model(model)
                    notes.append(f"Model access PASS: {metadata.get('id', model)}")
                except Exception as exc:
                    errors.append(f"Model access failed {model}: {exc}")

    result = {
        "status": "PASS" if not errors else "FAIL",
        "live": live,
        "errors": errors,
        "notes": notes,
        "counts": {
            "corpus_files": len(corpus_files),
            "items": len(items),
            "claims": len(claims),
            "evidence": len(evidence),
        },
        "live_plan_estimate": estimate,
        "generator_model": CONFIG["generator_model"],
        "embedding_model": CONFIG["embedding_model"],
        "store_responses": CONFIG["store_responses"],
    }
    (ROOT / "logs" / "preflight.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main("--live" in sys.argv))
