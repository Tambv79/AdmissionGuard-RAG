from __future__ import annotations

from pathlib import Path
import json
import statistics
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.common import CONFIG, load_jsonl


def usage_tokens(usage: dict) -> tuple[int, int]:
    return (
        int(usage.get("input_tokens", usage.get("prompt_tokens", 0)) or 0),
        int(usage.get("output_tokens", usage.get("completion_tokens", 0)) or 0),
    )


def main() -> int:
    generation_path = ROOT / "outputs" / "generation_results.jsonl"
    rows = load_jsonl(generation_path)
    groups: dict[str, list[dict]] = {}
    for row in rows:
        groups.setdefault(row["configuration_id"], []).append(row)

    pricing = CONFIG["pricing_snapshot"]
    summary = []
    for configuration_id, group_rows in sorted(groups.items()):
        input_tokens = 0
        output_tokens = 0
        for row in group_rows:
            inp, out = usage_tokens(row.get("usage", {}))
            input_tokens += inp
            output_tokens += out
        generation_cost = (
            input_tokens / 1_000_000 * float(pricing["generator_input_per_million_usd"])
            + output_tokens / 1_000_000 * float(pricing["generator_output_per_million_usd"])
        )
        summary.append(
            {
                "configuration_id": configuration_id,
                "n": len(group_rows),
                "must_include_recall_proxy": statistics.mean(
                    row["metrics_proxy"]["must_include_recall"] for row in group_rows
                ),
                "behavior_proxy_correct": statistics.mean(
                    row["metrics_proxy"]["behavior_proxy_correct"] for row in group_rows
                ),
                "citation_precision_proxy": statistics.mean(
                    row["metrics_proxy"]["citation_precision_proxy"] for row in group_rows
                ),
                "citation_presence_rate": statistics.mean(
                    row["metrics_proxy"]["has_citation"] for row in group_rows
                ),
                "mean_generation_latency_ms": statistics.mean(
                    row["generation_latency_ms"] for row in group_rows
                ),
                "p95_generation_latency_ms": sorted(
                    row["generation_latency_ms"] for row in group_rows
                )[max(0, int(0.95 * len(group_rows)) - 1)],
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "estimated_generation_cost_usd": generation_cost,
            }
        )

    expected_pairs = 60 * 6
    request_state = {}
    request_path = ROOT / "state" / "api_request_count.json"
    if request_path.exists():
        request_state = json.loads(request_path.read_text(encoding="utf-8"))
    cost_state = {}
    cost_path = ROOT / "state" / "cost_totals.json"
    if cost_path.exists():
        cost_state = json.loads(cost_path.read_text(encoding="utf-8"))

    result = {
        "status": "COMPLETE" if len(rows) == expected_pairs else "PARTIAL",
        "completed_generation_pairs": len(rows),
        "expected_generation_pairs": expected_pairs,
        "generation_summary_proxy": summary,
        "api_attempts": request_state.get("attempts", 0),
        "usage_cost_ledger": cost_state,
        "warning": (
            "Proxy metrics are for DEV configuration selection only. Final claim-level, citation, "
            "temporal and abstention scoring must use the locked evaluator and calibrated human protocol."
        ),
    }
    (ROOT / "outputs" / "final_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    zip_path = ROOT / "outputs" / "STEP3A_RESULTS_PARTIAL_OR_COMPLETE.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for folder in ("outputs", "logs", "state"):
            for path in (ROOT / folder).rglob("*"):
                if path.is_file() and path != zip_path:
                    archive.write(path, path.relative_to(ROOT))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(zip_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
