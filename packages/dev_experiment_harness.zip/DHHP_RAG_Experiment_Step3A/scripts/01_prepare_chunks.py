from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.chunking import prepare
if __name__=='__main__':
    rows=prepare(); counts={}
    for r in rows: counts[r['chunk_config_id']]=counts.get(r['chunk_config_id'],0)+1
    result={'status':'PASS','total_chunks':len(rows),'by_config':counts}
    (ROOT/'logs'/'prepare.json').write_text(json.dumps(result,indent=2),encoding='utf-8'); print(json.dumps(result,indent=2))
