# Chứng chỉ ngoại ngữ và trạng thái đăng ký
- Các chứng chỉ được xem xét gồm IELTS, TOEFL iBT, TOEIC 4 kỹ năng, HSK và JLPT theo quy định.
- Quy đổi IELTS: 5.0 thành 8,0; 5.5 thành 8,5; 6.0 thành 9,0; 6.5 thành 9,5; từ 7.0 đến 9.0 thành 10,0.
- TOEIC phải có đủ 4 kỹ năng; mức tối thiểu: Nghe 275, Đọc 275, Nói 120 và Viết 120.
- Không xét chứng chỉ ngoại ngữ thi theo hình thức Home Edition.
- Đăng ký quy đổi chứng chỉ đã kết thúc ngày 20/6/2026.
- Hệ thống đã khóa chức năng đăng ký từ ngày 21/6/2026.
- Kết quả quy đổi chỉ có giá trị trong kỳ tuyển sinh đại học chính quy năm 2026 và phải được Hội đồng tuyển sinh của Trường công nhận.
