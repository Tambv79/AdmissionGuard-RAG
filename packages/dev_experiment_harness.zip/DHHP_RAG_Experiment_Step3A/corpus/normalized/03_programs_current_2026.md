# Ngành, chương trình, tổ hợp, chỉ tiêu và ngưỡng hiện hành
- Snapshot: 2026-07-26.
- Tổng chỉ tiêu hiện hành: 3.195.

## 731010120 - Kinh tế: Logistics và vận tải đa phương thức (CLC)
- Mã ngành: 7310101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 731010120: 50.
- Ngưỡng PT1: 18.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734010120 - Quản trị kinh doanh: Kinh doanh số và đổi mới sáng tạo (CLC)
- Mã ngành: 7340101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 734010120: 50.
- Ngưỡng PT1: 17.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734010121 - Quản trị kinh doanh: Quản trị kinh doanh quốc tế (CLC)
- Mã ngành: 7340101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 734010121: 50.
- Ngưỡng PT1: 17.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734030120 - Kế toán: Kế toán doanh nghiệp theo định hướng ACCA (CLC)
- Mã ngành: 7340301
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C02, D01, D07
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 734030120: 50.
- Ngưỡng PT1: 17.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 748020120 - Công nghệ thông tin: Thiết kế game và Multimedia (CLC)
- Mã ngành: 7480201
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C02, D01, X26
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 748020120: 50.
- Ngưỡng PT1: 17.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 751030120 - Công nghệ kỹ thuật điện, điện tử: Công nghệ điện tử, vi mạch và bán dẫn (CLC)
- Mã ngành: 7510301
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, A02, A10, C01, D01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 751030120: 50.
- Ngưỡng PT1: 17.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 738010101 - Luật
- Mã ngành: 7380101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, C03, C04, D01, X01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 738010101: 70.
- Ngưỡng PT1: 20.00
- Điều kiện bổ sung: Điểm Toán >= 6 hoặc Ngữ văn >= 6 hoặc tổng điểm Toán + Ngữ văn >= 12.

## 734010101 - Quản trị kinh doanh
- Mã ngành: 7340101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Quản trị kinh doanh: 100; chưa công bố phân bổ riêng cho mã 734010101.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734010102 - Quản trị tài chính kế toán
- Mã ngành: 7340101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Quản trị kinh doanh: 100; chưa công bố phân bổ riêng cho mã 734010102.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734011501 - Marketing số
- Mã ngành: 7340115
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Marketing: 200; chưa công bố phân bổ riêng cho mã 734011501.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734011502 - Marketing
- Mã ngành: 7340115
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Marketing: 200; chưa công bố phân bổ riêng cho mã 734011502.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734011503 - Truyền thông marketing
- Mã ngành: 7340115
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Marketing: 200; chưa công bố phân bổ riêng cho mã 734011503.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734012201 - Thương mại điện tử
- Mã ngành: 7340122
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 734012201: 110.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734020102 - Tài chính doanh nghiệp
- Mã ngành: 7340201
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C02, D01, D07
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Tài chính - Ngân hàng: 125; chưa công bố phân bổ riêng cho mã 734020102.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734030102 - Kế toán doanh nghiệp
- Mã ngành: 7340301
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C02, D01, D07
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Kế toán: 150; chưa công bố phân bổ riêng cho mã 734030102.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 734030103 - Kế toán - Kiểm toán
- Mã ngành: 7340301
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C02, D01, D07
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Kế toán: 150; chưa công bố phân bổ riêng cho mã 734030103.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 722020101 - Ngôn ngữ Anh
- Mã ngành: 7220201
- Phương thức: PT1, PT3.1, PT5
- Tổ hợp: D01, D09, D10, D14, D15
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 722020101: 145.
- Ngưỡng PT1: 17.50
- Điều kiện bổ sung: Điểm môn Ngoại ngữ trong tổ hợp xét tuyển >= 6,0.

## 722020401 - Ngôn ngữ Trung Quốc
- Mã ngành: 7220204
- Phương thức: PT1, PT3.1, PT5
- Tổ hợp: D01, D04, D09, D14, D15, D45
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 722020401: 145.
- Ngưỡng PT1: 17.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 722903001 - Văn học
- Mã ngành: 7229030
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: C00, C03, C04, C19, C20, D15
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 722903001: 60.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 731010102 - Kinh tế ngoại thương
- Mã ngành: 7310101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Kinh tế: 150; chưa công bố phân bổ riêng cho mã 731010102.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 731010103 - Quản lý kinh tế
- Mã ngành: 7310101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Kinh tế: 150; chưa công bố phân bổ riêng cho mã 731010103.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 731010104 - Logistics và vận tải đa phương thức
- Mã ngành: 7310101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C03, C04, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Kinh tế: 150; chưa công bố phân bổ riêng cho mã 731010104.
- Ngưỡng PT1: 18.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 731040101 - Tâm lý học giáo dục
- Mã ngành: 7310401
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: C00, C03, C04, D01, D15, X01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Tâm lý học (dự kiến mở): 50; chưa công bố phân bổ riêng cho mã 731040101.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 731060801 - Nhật Bản học
- Mã ngành: 7310608
- Phương thức: PT1, PT3.1, PT5
- Tổ hợp: C00, D01, D04, D06, DD2
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Đông phương học (dự kiến mở): 50; chưa công bố phân bổ riêng cho mã 731060801.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 776010101 - Công tác xã hội
- Mã ngành: 7760101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: C00, C03, C04, D01, D15, X01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 776010101: 65.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 781010301 - Quản trị dịch vụ du lịch và lữ hành
- Mã ngành: 7810103
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: C00, C03, C04, D01, D14, D15
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Quản trị dịch vụ du lịch và lữ hành: 210; chưa công bố phân bổ riêng cho mã 781010301.
- Ngưỡng PT1: 17.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 781010302 - Quản trị lữ hành, khách sạn
- Mã ngành: 7810103
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: C00, C03, C04, D01, D14, D15
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Quản trị dịch vụ du lịch và lữ hành: 210; chưa công bố phân bổ riêng cho mã 781010302.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 781010303 - Hướng dẫn du lịch
- Mã ngành: 7810103
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: C00, C03, C04, D01, D14, D15
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Quản trị dịch vụ du lịch và lữ hành: 210; chưa công bố phân bổ riêng cho mã 781010303.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 748020101 - Công nghệ thông tin
- Mã ngành: 7480201
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C02, D01, X26
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Công nghệ thông tin: 135; chưa công bố phân bổ riêng cho mã 748020101.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 748020102 - Trí tuệ nhân tạo và Khoa học dữ liệu
- Mã ngành: 7480201
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, C01, C02, D01, X26
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Công nghệ thông tin: 135; chưa công bố phân bổ riêng cho mã 748020102.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 751010302 - Xây dựng dân dụng và công nghiệp
- Mã ngành: 7510103
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, A02, A10, C01, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Công nghệ kỹ thuật xây dựng: 70; chưa công bố phân bổ riêng cho mã 751010302.
- Ngưỡng PT1: 16.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 751020201 - Công nghệ chế tạo máy
- Mã ngành: 7510202
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, A02, A10, C01, D01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 751020201: 60.
- Ngưỡng PT1: 16.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 751020301 - Công nghệ kỹ thuật cơ điện tử
- Mã ngành: 7510203
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, A02, A10, C01, D01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 751020301: 110.
- Ngưỡng PT1: 17.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 751030102 - Điện công nghiệp và dân dụng
- Mã ngành: 7510301
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, A02, A10, C01, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Công nghệ kỹ thuật điện, điện tử: 65; chưa công bố phân bổ riêng cho mã 751030102.
- Ngưỡng PT1: 16.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 751030302 - Điện tự động công nghiệp
- Mã ngành: 7510303
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, A02, A10, C01, D01
- Chỉ tiêu: Nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm/ngành Công nghệ kỹ thuật điều khiển và tự động hóa: 120; chưa công bố phân bổ riêng cho mã 751030302.
- Ngưỡng PT1: 16.50
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 758010101 - Kiến trúc
- Mã ngành: 7580101
- Phương thức: PT1, PT2, PT3, PT4, PT5
- Tổ hợp: A00, A01, D01, V01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 758010101: 55.
- Ngưỡng PT1: 16.50
- Điều kiện bổ sung: Với tổ hợp V01, tổng điểm 02 môn văn hóa + điểm ưu tiên >= 11,00.

## 714020101 - Giáo dục Mầm non
- Mã ngành: 7140201
- Phương thức: PT1, PT3.1, PT5
- Tổ hợp: M00, M01, M02, M03, M04
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 714020101: 120.
- Ngưỡng PT1: 20.00
- Điều kiện bổ sung: Tổng điểm 02 môn văn hóa + điểm ưu tiên >= 13,33.

## 714020201 - Giáo dục Tiểu học
- Mã ngành: 7140202
- Phương thức: PT1, PT3.1, PT5
- Tổ hợp: A01, C01, C02, C03, C04, D01
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 714020201: 150.
- Ngưỡng PT1: 20.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 714020601 - Giáo dục Thể chất
- Mã ngành: 7140206
- Phương thức: PT1, PT2, PT5
- Tổ hợp: T00, T01, T02
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 714020601: 40.
- Ngưỡng PT1: 19.00
- Điều kiện bổ sung: Tổng điểm 02 môn văn hóa + điểm ưu tiên >= 12,67.

## 714020901 - Sư phạm Toán học
- Mã ngành: 7140209
- Phương thức: PT1, PT3.1, PT5
- Tổ hợp: A00, A01, C01, C02, D07
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 714020901: 110.
- Ngưỡng PT1: 20.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 714021701 - Sư phạm Ngữ văn
- Mã ngành: 7140217
- Phương thức: PT1, PT3.1, PT5
- Tổ hợp: C00, C03, C04, D01, D14, D15
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 714021701: 110.
- Ngưỡng PT1: 20.00
- Điều kiện bổ sung: Không có điều kiện bổ sung được công bố trong bảng ngưỡng.

## 714023101 - Sư phạm Tiếng Anh
- Mã ngành: 7140231
- Phương thức: PT1, PT3.1, PT5
- Tổ hợp: D01, D09, D10, D14, D15
- Chỉ tiêu: Chỉ tiêu dự kiến của mã 714023101: 120.
- Ngưỡng PT1: 20.00
- Điều kiện bổ sung: Điểm môn Ngoại ngữ trong tổ hợp xét tuyển >= 6,0.
