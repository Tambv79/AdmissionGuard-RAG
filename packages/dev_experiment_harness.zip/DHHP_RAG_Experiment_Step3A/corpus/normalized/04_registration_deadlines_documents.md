# Đăng ký, hồ sơ, lệ phí và minh chứng
- PT1 trên hệ thống của Bộ Giáo dục và Đào tạo: từ 02/7/2026 đến 17h00 ngày 14/7/2026.
- PT2 trên hệ thống tuyển sinh của Trường: từ 25/5/2026 đến 17h00 ngày 14/7/2026.
- PT3, PT4 và PT5: nhận hồ sơ từ 25/5/2026 đến 20/6/2026.
- Đăng ký thi năng khiếu: từ 02/4/2026 đến 30/5/2026.
- Lệ phí hồ sơ thuộc mục 6.4 Thông báo 1889: 100.000 đồng/hồ sơ.
- Lệ phí thi năng khiếu: 300.000 đồng/01 môn thi/thí sinh.
- Minh chứng tải lên https://dkxt.dhhp.edu.vn.
- Tên tệp minh chứng theo cấu trúc ĐHHP_SốCCCD_TênMinhChứng.
