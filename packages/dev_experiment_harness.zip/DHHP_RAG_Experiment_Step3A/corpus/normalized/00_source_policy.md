# Chính sách nguồn và thời gian
Corpus: DHHP-Admission-Corpus-v1.0.1
Corpus cha: DHHP-Admission-Corpus-v1.0
Ngày khóa dữ liệu: 2026-07-26

- Ưu tiên nguồn theo từng trường dữ liệu.
- Chỉ tiêu hiện hành dùng snapshot cổng tuyển sinh: tổng 3.195.
- Tổng 4.365 trong Thông báo tháng 5 được giữ làm dữ liệu lịch sử, không dùng cho câu hỏi hiện hành.
- Thông báo 1889/TB-ĐHHP dùng cho điều kiện, phương thức, hồ sơ, thời hạn, lệ phí và bảng quy đổi chứng chỉ.
- Thông báo ngày 10/7/2026 dùng cho ngưỡng đầu vào, quy đổi tương đương và ưu đãi chương trình chất lượng cao.
- Không suy đoán chỉ tiêu riêng khi nguồn hiện hành chỉ công bố chỉ tiêu nhóm.
- Khi thiếu bằng chứng, từ chối có căn cứ và cung cấp kênh liên hệ chính thức.
