# Ngưỡng đầu vào và quy đổi tương đương
- PT1 là phương thức gốc.
- Điểm PT2, PT3 và PT4 phải quy đổi về PT1.
- Mỗi mã xét tuyển có một ngưỡng đầu vào và một điểm trúng tuyển chung sau quy đổi.
- Bảng ngưỡng của 42 mã xét tuyển nằm trong structured/thresholds_current_2026.csv.
- Công cụ tra cứu quy đổi: https://tuyensinh.dhhp.edu.vn/tool/conversion/score/2026.
