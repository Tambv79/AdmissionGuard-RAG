# Thông tin chung và liên hệ
- Phạm vi corpus: tuyển sinh đại học chính quy năm 2026.
- Địa chỉ: 171 Phan Đăng Lưu, Phù Liễn, Hải Phòng.
- Hotline tư vấn tuyển sinh: 0398.171.171.
- Email: tuyensinh@dhhp.edu.vn.
- Cổng thông tin Trường: https://dhhp.edu.vn.
- Cổng thông tin tuyển sinh: https://tuyensinh.dhhp.edu.vn/.
- Hệ thống đăng ký xét tuyển: https://dkxt.dhhp.edu.vn.
- Phạm vi tuyển sinh: toàn quốc.
- Đối với các ngành đào tạo giáo viên, thí sinh phải có hộ khẩu thường trú tại Hải Phòng và đăng ký trước thời điểm Bộ Giáo dục và Đào tạo mở hệ thống đăng ký xét tuyển đại học.
