# Học phí, học bổng và ưu đãi
- Ngành đào tạo giáo viên: Sinh viên khối ngành đào tạo giáo viên khi đăng ký hưởng chính sách theo Nghị định 116/NĐ-CP ngày 25/9/2020 của Chính phủ thì không phải đóng học phí.
- Học phí chung: Tài liệu tuyển sinh 2026 chưa công bố mức học phí cụ thể theo từng ngành; học phí và lộ trình tăng học phí thực hiện theo quy định hiện hành của Nhà trường/Nhà nước.
- Chính sách theo Nghị định 179: Sinh viên theo học Công nghệ thông tin; Thiết kế Game và Multimedia - CLC; Trí tuệ nhân tạo và Khoa học dữ liệu có thể thuộc đối tượng học bổng theo Nghị định 179/2026/NĐ-CP nếu đáp ứng điều kiện; mức hưởng 3.700.000 đồng/tháng.
- Chính sách nhân tài thành phố Hải Phòng: Theo Nghị quyết 53/2025/NQ-HĐND, thành phố Hải Phòng hỗ trợ 100% học phí cho một số đối tượng tài năng theo điều kiện cam kết học tập và làm việc.
- Chương trình chất lượng cao: học bổng 100% học phí năm thứ nhất nếu điểm trúng tuyển PT1 từ 27,00 trở lên.
- Chương trình chất lượng cao: học bổng 50% học phí năm thứ nhất nếu điểm trúng tuyển PT1 từ 25,00 đến dưới 27,00.
- Sinh viên chương trình chất lượng cao được miễn phí gửi xe và miễn phí ở Ký túc xá trong năm thứ nhất.
