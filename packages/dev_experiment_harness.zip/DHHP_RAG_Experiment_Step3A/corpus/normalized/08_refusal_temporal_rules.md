# Quy tắc từ chối và kiểm soát thời gian
1. Không dự đoán điểm chuẩn, tỉ lệ chọi, khả năng đỗ hoặc số lượng hồ sơ tương lai.
2. Không dùng tổng chỉ tiêu 4.365 cho câu hỏi hiện hành; snapshot hiện hành là 3.195.
3. Không dùng chỉ tiêu cũ của từng chuyên ngành khi nguồn hiện hành chỉ công bố tổng chỉ tiêu nhóm.
4. Câu hỏi về thời hạn phải nêu ngày áp dụng và trạng thái đã hết hạn hay còn hiệu lực.
5. Khi thiếu bằng chứng, phải nói nguồn chính thức hiện có chưa công bố thông tin và cung cấp hotline hoặc email.
6. Không trả lời các nội dung ngoài phạm vi tuyển sinh đại học chính quy năm 2026 bằng cách suy đoán từ kiến thức chung.
