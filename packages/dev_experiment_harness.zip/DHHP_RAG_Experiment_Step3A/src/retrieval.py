from __future__ import annotations
import math, statistics
from collections import Counter
from .common import lexical_tokens

class BM25:
    def __init__(self, chunks, k1=1.5, b=0.75):
        self.chunks=chunks; self.k1=k1; self.b=b
        self.docs=[lexical_tokens(c['text']) for c in chunks]
        self.N=len(self.docs); self.avgdl=sum(map(len,self.docs))/max(1,self.N)
        self.df=Counter()
        for d in self.docs:
            for t in set(d): self.df[t]+=1
    def score(self, query):
        q=lexical_tokens(query); out=[]
        for idx,d in enumerate(self.docs):
            tf=Counter(d); dl=len(d); s=0.0
            for t in q:
                if t not in tf: continue
                idf=math.log(1+(self.N-self.df[t]+0.5)/(self.df[t]+0.5))
                f=tf[t]; s+=idf*(f*(self.k1+1))/(f+self.k1*(1-self.b+self.b*dl/max(1,self.avgdl)))
            out.append((idx,s))
        return sorted(out,key=lambda x:(-x[1],self.chunks[x[0]]['chunk_id']))

def cosine(a,b):
    dot=sum(x*y for x,y in zip(a,b)); na=math.sqrt(sum(x*x for x in a)); nb=math.sqrt(sum(y*y for y in b))
    return dot/(na*nb) if na and nb else 0.0

def dense_rank(chunks, chunk_vectors, query_vector):
    scored=[(i,cosine(v,query_vector)) for i,v in enumerate(chunk_vectors)]
    return sorted(scored,key=lambda x:(-x[1],chunks[x[0]]['chunk_id']))

def rrf(chunks, rank_a, rank_b, k=60):
    score={}
    for rank_list in (rank_a,rank_b):
        for r,(idx,_) in enumerate(rank_list,1): score[idx]=score.get(idx,0.0)+1.0/(k+r)
    return sorted(score.items(),key=lambda x:(-x[1],chunks[x[0]]['chunk_id']))

def token_f1(a,b):
    ca=Counter(lexical_tokens(a)); cb=Counter(lexical_tokens(b)); overlap=sum((ca&cb).values())
    if not ca or not cb or overlap==0:return 0.0
    p=overlap/sum(ca.values()); r=overlap/sum(cb.values()); return 2*p*r/(p+r)

def relevance(chunk, gold_evidence):
    best=0.0
    for ev in gold_evidence:
        doc=ev['document_id'].replace('\\','/').split('/')[-1]
        if doc!=chunk['filename']: continue
        f1=token_f1(chunk['text'],ev['evidence_text'])
        if ev['evidence_text'].strip() in chunk['text']: f1=max(f1,1.0)
        best=max(best,f1)
    return best

def metrics_for_ranked(chunks, ranked, gold_evidence, ks=(1,3,5,10), threshold=0.25):
    rels=[relevance(chunks[i],gold_evidence) for i,_ in ranked]
    gold_count=max(1,len(gold_evidence)); out={}
    for k in ks:
        top=rels[:k]; hits=sum(1 for x in top if x>=threshold)
        out[f'hit_at_{k}']=1 if hits else 0
        out[f'evidence_recall_at_{k}']=min(1.0,hits/gold_count)
        dcg=sum((2**x-1)/math.log2(i+2) for i,x in enumerate(top))
        ideal=sorted(rels,reverse=True)[:k]; idcg=sum((2**x-1)/math.log2(i+2) for i,x in enumerate(ideal))
        out[f'ndcg_at_{k}']=dcg/idcg if idcg else 0.0
    first=next((i for i,x in enumerate(rels,1) if x>=threshold),None); out['mrr']=1/first if first else 0.0
    return out
