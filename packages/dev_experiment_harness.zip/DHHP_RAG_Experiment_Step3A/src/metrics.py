from __future__ import annotations
import re
from .common import norm

def generation_metrics(item, answer, retrieved_ids):
    gold=item['gold_answer']; a=norm(answer); must=gold.get('must_include',[]); forbidden=gold.get('must_not_include',[])
    must_hits=sum(1 for x in must if norm(str(x)) in a)
    forbidden_hits=sum(1 for x in forbidden if norm(str(x)) in a)
    required_recall=must_hits/len(must) if must else 1.0
    citation_ids=re.findall(r'\[([^\[\]]+__t(?:256|512|768)_o(?:64|128|192)__c\d{4})\]',answer)
    citation_precision=sum(1 for x in citation_ids if x in set(retrieved_ids))/len(citation_ids) if citation_ids else 0.0
    action=item['expected_action']; lower=answer.lower()
    refusal_terms=['chưa công bố','không thể','không đủ thông tin','không có căn cứ','không thể dự đoán','vui lòng cho biết thêm']
    refused=any(x in lower for x in refusal_terms)
    expected_refusal=action.startswith('REFUSE') or action in ('CLARIFY','CORRECT_FALSE_PREMISE')
    behavior_ok=(refused if expected_refusal else not refused)
    return {'must_include_recall':required_recall,'must_not_include_violations':forbidden_hits,
            'citation_precision_proxy':citation_precision,'has_citation':1 if citation_ids else 0,
            'behavior_proxy_correct':1 if behavior_ok else 0}
