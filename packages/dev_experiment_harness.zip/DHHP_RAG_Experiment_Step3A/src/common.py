from __future__ import annotations

import csv
import hashlib
import json
import os
import random
import re
import time
import unicodedata
from pathlib import Path
from urllib import error, request

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config" / "experiment_config.json").read_text(encoding="utf-8"))
WORD_RE = re.compile(r"[0-9A-Za-zÀ-ỹĐđ]+(?:[./:@_-][0-9A-Za-zÀ-ỹĐđ]+)*", re.UNICODE)


def lexical_tokens(text: str) -> list[str]:
    return [m.group(0).lower() for m in WORD_RE.finditer(unicodedata.normalize("NFC", text))]


def norm(text: str) -> str:
    return " ".join(lexical_tokens(text))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def append_jsonl(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(obj, ensure_ascii=False) + "\n")
        stream.flush()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, headers: list[str], rows: list[list]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(headers)
        writer.writerows(rows)


def _reserve_api_attempt(endpoint: str) -> int:
    """Persistently reserve one HTTP attempt before sending it.

    The counter survives interruption and therefore prevents an accidental retry
    loop from exceeding the authorized request ceiling.
    """
    state_path = ROOT / "state" / "api_request_count.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state = {"attempts": 0, "history": []}
    if state_path.exists():
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    maximum = int(CONFIG["cost_guard"]["max_live_requests"])
    current = int(state.get("attempts", 0))
    if current >= maximum:
        raise RuntimeError(
            f"API request guard reached {current}/{maximum}. "
            "Inspect logs before authorizing any additional requests."
        )
    current += 1
    history = list(state.get("history", []))[-99:]
    history.append({"attempt": current, "endpoint": endpoint, "time_utc": time.time()})
    temp = state_path.with_suffix(".tmp")
    temp.write_text(json.dumps({"attempts": current, "history": history}, indent=2), encoding="utf-8")
    temp.replace(state_path)
    return current


def api_json(method: str, endpoint: str, payload=None, timeout: int = 120) -> dict:
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("OPENAI_API_KEY is missing.")
    url = "https://api.openai.com/v1/" + endpoint.lstrip("/")
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    cfg = CONFIG["retry"]
    last_error: Exception | None = None
    for attempt in range(1, int(cfg["max_attempts"]) + 1):
        _reserve_api_attempt(endpoint)
        req = request.Request(
            url,
            data=data,
            method=method.upper(),
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "User-Agent": "DHHP-RAG-Experiment/1.1",
            },
        )
        try:
            with request.urlopen(req, timeout=timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except error.HTTPError as exc:
            body = exc.read().decode("utf-8", "replace")
            last_error = RuntimeError(f"HTTP {exc.code}: {body}")
            if exc.code not in (408, 409, 429, 500, 502, 503, 504):
                raise last_error
        except Exception as exc:  # network and timeout errors
            last_error = exc
        if attempt < int(cfg["max_attempts"]):
            delay = min(
                float(cfg["max_delay_seconds"]),
                float(cfg["base_delay_seconds"]) * (2 ** (attempt - 1)),
            ) + random.random()
            time.sleep(delay)
    raise RuntimeError(f"API failed after retries: {last_error}")


def output_text(response: dict) -> str:
    if isinstance(response.get("output_text"), str):
        return response["output_text"].strip()
    parts: list[str] = []
    for item in response.get("output", []):
        if item.get("type") != "message":
            continue
        for content in item.get("content", []):
            if content.get("type") == "output_text" and isinstance(content.get("text"), str):
                parts.append(content["text"])
    return "\n".join(parts).strip()
