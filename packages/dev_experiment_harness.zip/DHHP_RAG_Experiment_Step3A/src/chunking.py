from __future__ import annotations
import json, re
from pathlib import Path
from .common import ROOT, CONFIG, lexical_tokens, sha256_file

def split_markdown(text: str, max_tokens: int, overlap: int):
    lines=text.splitlines()
    units=[]; current_heading='ROOT'
    for line_no,line in enumerate(lines,1):
        if line.startswith('#'):
            current_heading=line.lstrip('#').strip() or current_heading
        if line.strip(): units.append({'line':line_no,'heading':current_heading,'text':line})
    flat=[]
    for u in units:
        toks=lexical_tokens(u['text'])
        if toks: flat.append((u,toks))
    chunks=[]; i=0; chunk_idx=1
    while i<len(flat):
        tok_count=0; j=i; selected=[]
        while j<len(flat):
            n=len(flat[j][1])
            if selected and tok_count+n>max_tokens: break
            selected.append(flat[j]); tok_count+=n; j+=1
        if not selected: selected=[flat[i]]; j=i+1; tok_count=len(flat[i][1])
        start=selected[0][0]['line']; end=selected[-1][0]['line']
        heading=selected[0][0]['heading']
        body='\n'.join(x[0]['text'] for x in selected)
        chunks.append({'chunk_index':chunk_idx,'line_start':start,'line_end':end,'heading':heading,'text':body,'lexical_token_count':tok_count})
        chunk_idx+=1
        if j>=len(flat): break
        # overlap in lexical tokens by backing up whole line units.
        back=0; next_i=j
        while next_i>i+1 and back<overlap:
            next_i-=1; back+=len(flat[next_i][1])
        i=next_i
    return chunks

def prepare():
    corpus_dir=ROOT/'corpus'/'normalized'; out=ROOT/'state'/'chunks'; out.mkdir(parents=True,exist_ok=True)
    all_manifest=[]
    for cfg in CONFIG['chunk_configs']:
        cfg_dir=out/cfg['id']; cfg_dir.mkdir(parents=True,exist_ok=True)
        manifest=[]
        for path in sorted(corpus_dir.glob('*.md')):
            text=path.read_text(encoding='utf-8')
            for ch in split_markdown(text,cfg['max_lexical_tokens'],cfg['overlap_lexical_tokens']):
                cid=f"{path.stem}__{cfg['id']}__c{ch['chunk_index']:04d}"
                row={'chunk_id':cid,'chunk_config_id':cfg['id'],'document_id':f'normalized/{path.name}','filename':path.name,
                     'line_start':ch['line_start'],'line_end':ch['line_end'],'heading':ch['heading'],'text':ch['text'],
                     'lexical_token_count':ch['lexical_token_count'],'source_sha256':sha256_file(path)}
                manifest.append(row); all_manifest.append(row)
        (cfg_dir/'chunks.jsonl').write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in manifest)+'\n',encoding='utf-8')
    (out/'all_chunks.jsonl').write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in all_manifest)+'\n',encoding='utf-8')
    return all_manifest
