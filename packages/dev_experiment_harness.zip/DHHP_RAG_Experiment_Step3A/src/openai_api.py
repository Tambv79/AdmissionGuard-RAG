from __future__ import annotations

import json
import time
from pathlib import Path

from .common import CONFIG, ROOT, api_json, append_jsonl, output_text


def verify_model(model: str) -> dict:
    return api_json("GET", f"models/{model}")


def _price_for(call_type: str) -> tuple[float, float]:
    pricing = CONFIG["pricing_snapshot"]
    if call_type == "embedding":
        return float(pricing["embedding_input_per_million_usd"]), 0.0
    return (
        float(pricing["generator_input_per_million_usd"]),
        float(pricing["generator_output_per_million_usd"]),
    )


def record_usage(call_type: str, model: str, usage: dict, response_id: str | None = None) -> dict:
    input_tokens = int(usage.get("input_tokens", usage.get("prompt_tokens", 0)) or 0)
    output_tokens = int(usage.get("output_tokens", usage.get("completion_tokens", 0)) or 0)
    input_rate, output_rate = _price_for(call_type)
    estimated_usd = input_tokens / 1_000_000 * input_rate + output_tokens / 1_000_000 * output_rate
    row = {
        "time_utc": time.time(),
        "call_type": call_type,
        "model": model,
        "response_id": response_id,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "estimated_usd": estimated_usd,
        "pricing_snapshot_date": CONFIG["pricing_snapshot"]["date"],
    }
    ledger = ROOT / "state" / "usage_ledger.jsonl"
    append_jsonl(ledger, row)

    rows = []
    if ledger.exists():
        rows = [json.loads(line) for line in ledger.read_text(encoding="utf-8").splitlines() if line.strip()]
    total = sum(float(x.get("estimated_usd", 0.0)) for x in rows)
    totals = {
        "calls_with_usage": len(rows),
        "estimated_total_usd": total,
        "max_authorized_usd": float(CONFIG["cost_guard"]["max_estimated_usd"]),
        "pricing_snapshot_date": CONFIG["pricing_snapshot"]["date"],
    }
    (ROOT / "state" / "cost_totals.json").write_text(json.dumps(totals, indent=2), encoding="utf-8")
    if total > totals["max_authorized_usd"]:
        raise RuntimeError(
            f"Cost guard exceeded: estimated ${total:.4f} > ${totals['max_authorized_usd']:.2f}."
        )
    return row


def embed(texts: list[str], model: str | None = None) -> tuple[list[list[float]], dict]:
    selected_model = model or CONFIG["embedding_model"]
    response = api_json("POST", "embeddings", {"model": selected_model, "input": texts}, timeout=300)
    data = sorted(response["data"], key=lambda item: item["index"])
    usage = response.get("usage", {})
    record_usage("embedding", selected_model, usage, response.get("id"))
    return [item["embedding"] for item in data], usage


def response_call(
    instructions: str,
    user_input: str,
    model: str | None = None,
    max_output_tokens: int | None = None,
    call_type: str = "generation",
) -> dict:
    payload = {
        "model": model or CONFIG["generator_model"],
        "instructions": instructions,
        "input": user_input,
        "max_output_tokens": max_output_tokens or CONFIG["max_output_tokens"],
        "store": CONFIG["store_responses"],
        "reasoning": {"effort": CONFIG["reasoning_effort"]},
        "text": {"verbosity": CONFIG["text_verbosity"]},
    }
    started = time.perf_counter()
    raw = api_json("POST", "responses", payload, timeout=300)
    latency_ms = (time.perf_counter() - started) * 1000
    resolved_model = raw.get("model", payload["model"])
    usage = raw.get("usage", {})
    record_usage(call_type, resolved_model, usage, raw.get("id"))
    return {
        "answer": output_text(raw),
        "raw": raw,
        "latency_ms": latency_ms,
        "usage": usage,
        "model": resolved_model,
        "response_id": raw.get("id"),
    }


def rerank(question: str, candidates: list[dict]) -> tuple[list[str], dict]:
    compact = [
        {
            "chunk_id": candidate["chunk_id"],
            "source": candidate["filename"],
            "text": candidate["text"][:1800],
        }
        for candidate in candidates
    ]
    prompt = (
        "Rank the candidate passages for answering the Vietnamese admission question. "
        "Return JSON only in the form {\"ranking\":[\"chunk_id\", ...]}. "
        "Rank every candidate exactly once and add no commentary.\n\n"
        f"QUESTION:\n{question}\n\nCANDIDATES:\n{json.dumps(compact, ensure_ascii=False)}"
    )
    result = response_call(
        "You are a multilingual passage reranker. Follow the JSON-only format exactly.",
        prompt,
        max_output_tokens=500,
        call_type="rerank",
    )
    ranking: list[str] = []
    text = result["answer"]
    try:
        start = text.find("{")
        end = text.rfind("}") + 1
        parsed = json.loads(text[start:end])
        ranking = [str(value) for value in parsed.get("ranking", [])]
    except Exception:
        ranking = []
    valid_ids = {candidate["chunk_id"] for candidate in candidates}
    ranking = [chunk_id for chunk_id in ranking if chunk_id in valid_ids]
    ranking.extend(
        candidate["chunk_id"] for candidate in candidates if candidate["chunk_id"] not in ranking
    )
    return ranking, result
