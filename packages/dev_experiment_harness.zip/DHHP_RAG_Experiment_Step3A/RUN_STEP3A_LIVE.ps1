$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:PYTHONUTF8 = "1"

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "Python 3.11 or later was not found in PATH."
}

python -c "import sys; assert sys.version_info >= (3,11), 'Python 3.11+ is required'; print(sys.version)"
if ($LASTEXITCODE -ne 0) { throw "Python version check failed." }

if (-not $env:OPENAI_API_KEY) {
    throw "Set OPENAI_API_KEY in this PowerShell session. Never send or upload the key."
}
if ($env:DHHP_APPROVE_API_COST -ne "YES") {
    throw "Set DHHP_APPROVE_API_COST=YES to authorize the controlled live DEV run."
}

python .\run_all.py --live
if ($LASTEXITCODE -ne 0) {
    throw "Step 3A stopped. Review logs; checkpoint files are preserved for an exact resume."
}
Write-Host "PASS: Step 3A finished. Return only outputs\STEP3A_RESULTS_PARTIAL_OR_COMPLETE.zip." -ForegroundColor Green
