# DHHP RAG Experiment — Step 3A

Status: `PASS_HARNESS_BUILT_LOCAL_QA_COMPLETE_LIVE_API_RUN_REQUIRED`

This package runs **real development-set experiments**. It contains no fabricated scientific result. Synthetic text occurs only inside `scripts/selftest.py` for software QA and is never mixed with research outputs.

## Locked inputs

- Corpus: `DHHP-Admission-Corpus-v1.0.1`
- Benchmark: `DEV-Gold-v1.0` — 60 items, 127 atomic claims, 89 evidence spans
- Generator/reranker: `gpt-5.6-terra`
- Embeddings: `text-embedding-3-large`
- Response storage: `store=false`

GPT-5.6 Terra currently has no dated snapshot listed. Therefore, every raw result records the resolved model ID returned by the API and the execution date. No hidden TEST or STRESS item is included.

## One exact Windows PowerShell command

Run from the extracted package folder after replacing the key **locally**:

```powershell
$env:OPENAI_API_KEY="YOUR_KEY"; $env:DHHP_APPROVE_API_COST="YES"; powershell -ExecutionPolicy Bypass -File .\RUN_STEP3A_LIVE.ps1
```

Never upload or send the API key. Return only:

```text
outputs\STEP3A_RESULTS_PARTIAL_OR_COMPLETE.zip
```

## Fail-fast and resume controls

1. Python 3.11+ and UTF-8 checks.
2. Locked-corpus and DEV-Gold count validation.
3. Model-access validation before the expensive stages.
4. Conservative cost estimate checked against the USD 15 authorization ceiling.
5. Persistent ceiling of 700 HTTP attempts, including retries.
6. Exponential retry with preserved embedding, reranking, and generation checkpoints.
7. A finalizer that always packages completed partial or full results without retraining.
8. API-reported token usage and a dated price snapshot used for the cost ledger.

## Real experimental workflow

1. Deterministic chunk preparation for 256/64, 512/128, and 768/192 lexical-token settings.
2. BM25, dense embedding, and reciprocal-rank-fusion retrieval screening.
3. GPT reranking of the selected hybrid candidate pool, cached once per query.
4. Generation screening for:
   - C0 LLM-only
   - C1 BM25-RAG
   - C2 Dense RAG
   - C3 Hybrid RAG
   - C4 Hybrid + reranker
   - C5 Full temporal/citation/refusal control
5. Partial-result finalization and packaging.

## Scientific boundary

The development proxy metrics are used only for configuration selection. They are not final TEST evidence. The returned raw outputs will be scored in Step 3B with the locked atomic-claim, citation, temporal, abstention, statistical, and calibrated-human protocol.
