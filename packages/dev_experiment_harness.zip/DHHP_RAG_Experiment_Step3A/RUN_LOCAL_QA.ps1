$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:PYTHONUTF8 = "1"
python .\run_all.py
if ($LASTEXITCODE -ne 0) { throw "Local QA failed." }
Write-Host "PASS: local engineering QA and real local BM25 DEV screening completed." -ForegroundColor Green
