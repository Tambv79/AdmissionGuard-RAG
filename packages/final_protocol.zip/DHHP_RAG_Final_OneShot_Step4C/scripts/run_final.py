#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import os,json,time,urllib.request,urllib.error,hashlib,math,re,zipfile,sys,statistics,unicodedata
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
for d in ['state','outputs','logs']:(ROOT/d).mkdir(exist_ok=True)
CFG=json.load(open(ROOT/'config/final_experiment_config.json',encoding='utf-8'))
API='https://api.openai.com/v1'
KEY=os.environ.get('OPENAI_API_KEY','').strip()
APPROVE=os.environ.get('DHHP_APPROVE_API_COST','').strip().upper()
if not KEY: raise SystemExit('OPENAI_API_KEY is missing. No API request was sent.')
if APPROVE!='YES': raise SystemExit('Set DHHP_APPROVE_API_COST=YES. No API request was sent.')
if CFG['generator_model']!='gpt-5.6-terra': raise SystemExit('Model lock violation.')

def jload(p,default=None):
    p=Path(p)
    if not p.exists(): return default
    return json.load(open(p,encoding='utf-8'))
def jwrite(p,obj):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(p)
def jsonl(path):
    p=Path(path)
    return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()] if p.exists() else []
def append_jsonl(path,obj):
    with open(path,'a',encoding='utf-8') as f:f.write(json.dumps(obj,ensure_ascii=False)+'\n')
def req(method,path,body=None,content_type='application/json'):
    data=None
    headers={'Authorization':'Bearer '+KEY}
    if body is not None:
        if content_type=='application/json': data=json.dumps(body).encode();headers['Content-Type']=content_type
        else: data=body;headers['Content-Type']=content_type
    r=urllib.request.Request(API+path,data=data,headers=headers,method=method)
    try:
        with urllib.request.urlopen(r,timeout=120) as resp:
            b=resp.read(); return json.loads(b) if b and 'json' in resp.headers.get('Content-Type','') else b
    except urllib.error.HTTPError as e:
        msg=e.read().decode(errors='replace')
        raise RuntimeError(f'HTTP {e.code} {path}: {msg[:2000]}')

def get_file_content(fid): return req('GET',f'/files/{fid}/content')
def upload_batch_file(path):
    boundary='----DHHP'+hashlib.sha256(str(path).encode()).hexdigest()[:20]
    content=Path(path).read_bytes()
    parts=[]
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="purpose"\r\n\r\nbatch\r\n'.encode())
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{Path(path).name}"\r\nContent-Type: application/jsonl\r\n\r\n'.encode()+content+b'\r\n')
    parts.append(f'--{boundary}--\r\n'.encode())
    return req('POST','/files',b''.join(parts),f'multipart/form-data; boundary={boundary}')
def wait_batch(batch_id,state_path):
    while True:
        b=req('GET',f'/batches/{batch_id}');jwrite(state_path,b)
        print('Batch',batch_id,b.get('status'),b.get('request_counts'))
        if b.get('status') in {'completed','failed','expired','cancelled'}: return b
        time.sleep(30)
def ensure_batch(stage,input_jsonl,endpoint):
    state=ROOT/'state'/f'{stage}_batch.json'
    b=jload(state)
    if not b:
        up=upload_batch_file(input_jsonl)
        b=req('POST','/batches',{'input_file_id':up['id'],'endpoint':endpoint,'completion_window':'24h','metadata':{'project':'DHHP-RAG','stage':stage}})
        jwrite(state,b)
    if b.get('status') not in {'completed','failed','expired','cancelled'}: b=wait_batch(b['id'],state)
    if b.get('status')!='completed': raise RuntimeError(f'{stage} batch ended as {b.get("status")}')
    out=ROOT/'state'/f'{stage}_output.jsonl'
    if not out.exists(): out.write_bytes(get_file_content(b['output_file_id']))
    return b,out

def response_text(body):
    out=[]
    for x in body.get('output',[]):
        if x.get('type')=='message':
            for c in x.get('content',[]):
                if c.get('type')=='output_text': out.append(c.get('text',''))
    return '\n'.join(out).strip()
def parse_batch(path):
    d={}
    for row in jsonl(path):
        cid=row['custom_id'];resp=row.get('response') or {};body=resp.get('body') or {}
        if resp.get('status_code')!=200: raise RuntimeError(f'Failed batch row {cid}: {row}')
        d[cid]=body
    return d

def fold(s):
    s=unicodedata.normalize('NFD',s.lower().replace('đ','d'))
    return re.sub(r'\s+',' ',''.join(c for c in s if unicodedata.category(c)!='Mn')).strip()
def toks(s): return re.findall(r'[a-z0-9]+',fold(s))
class BM25:
    def __init__(self,chunks):
        self.chunks=chunks;self.docs=[toks(c['text']) for c in chunks];self.N=len(chunks);self.avg=sum(map(len,self.docs))/self.N
        self.df=Counter()
        for d in self.docs:self.df.update(set(d))
    def score(self,q):
        qs=toks(q);out=[];k1=1.5;b=.75
        for i,d in enumerate(self.docs):
            tf=Counter(d);score=0
            for term in qs:
                if term not in self.df:continue
                idf=math.log(1+(self.N-self.df[term]+.5)/(self.df[term]+.5));f=tf[term]
                score+=idf*(f*(k1+1))/(f+k1*(1-b+b*len(d)/self.avg))
            out.append((i,score))
        return sorted(out,key=lambda x:(-x[1],x[0]))
def cosine(a,b):
    num=sum(x*y for x,y in zip(a,b));da=math.sqrt(sum(x*x for x in a));db=math.sqrt(sum(x*x for x in b));return num/(da*db) if da and db else 0
def rrf(a,b,k=60):
    s=Counter()
    for rank,(i,_) in enumerate(a,1):s[i]+=1/(k+rank)
    for rank,(i,_) in enumerate(b,1):s[i]+=1/(k+rank)
    return sorted(s.items(),key=lambda x:(-x[1],x[0]))
def estimated_cost(usages):
    pr=CFG['batch_prices_per_million'];total=0
    for kind,u in usages:
        if kind=='embedding':total+=u.get('total_tokens',u.get('input_tokens',0))*pr['embedding_input']/1e6
        else:total+=u.get('input_tokens',0)*pr['gpt_input']/1e6+u.get('output_tokens',0)*pr['gpt_output']/1e6
    return total

def route_plan(): return {x['item_id']:x for x in jsonl(ROOT/'benchmark/C6_ROUTE_PLAN.jsonl')}
items=jsonl(ROOT/'benchmark/TEST_STRESS_GOLD_v1.0.jsonl');routes=route_plan();api_items=[x for x in items if not routes[x['item_id']]['handled']]
if len(items)!=300: raise SystemExit('Benchmark count mismatch; no request sent.')
# Model permission check is a free GET and fails before any paid batch.
for model in [CFG['generator_model'],CFG['embedding_model']]:
    try:req('GET','/models/'+model)
    except Exception as e: raise SystemExit(f'Model {model} is not allowed in this project. Add it under Project Settings > Limits > Model usage. No paid batch was submitted. Details: {e}')
# Absolute hard guard.
if CFG['all_300_hard_cap_usd']>CFG['experiment_hard_ceiling_usd']:raise SystemExit('Hard budget invariant failed.')

# Stage 1: query embeddings.
emb_in=ROOT/'state/embedding_input.jsonl'
if not emb_in.exists():
    with open(emb_in,'w',encoding='utf-8') as f:
        for x in api_items:
            row={'custom_id':x['item_id'],'method':'POST','url':'/v1/embeddings','body':{'model':CFG['embedding_model'],'input':x['question_text_vi'],'encoding_format':'float'}}
            f.write(json.dumps(row,ensure_ascii=False)+'\n')
_,emb_out=ensure_batch('embedding',emb_in,'/v1/embeddings')
embodies=parse_batch(emb_out);qvec={k:v['data'][0]['embedding'] for k,v in embodies.items()};usages=[('embedding',v.get('usage',{})) for v in embodies.values()]

# Retrieval with locked corpus embeddings.
chunks=jsonl(ROOT/'corpus/chunks_t512_o128.jsonl');cvec=jload(ROOT/'corpus/chunk_embeddings_text-embedding-3-large.json')['vectors'];bm=BM25(chunks)
retr={}
for x in api_items:
    br=bm.score(x['question_text_vi']);dr=sorted([(i,cosine(cvec[i],qvec[x['item_id']])) for i in range(len(chunks))],key=lambda z:(-z[1],z[0]));hr=rrf(br,dr,CFG['rrf_k'])
    retr[x['item_id']]=[chunks[i] for i,_ in hr[:CFG['candidate_k']]]
jwrite(ROOT/'state/retrieval_candidates.json',retr)

# Budget gate before rerank.
actual=estimated_cost(usages)
remaining=len(api_items)*((8000*1.25+300*7.5)+(8000*1.25+450*7.5))/1e6
if actual+remaining>CFG['experiment_hard_ceiling_usd']:raise SystemExit(f'Budget guard stopped before rerank: {actual+remaining:.4f} > 8.50')

# Stage 2: rerank.
rr_in=ROOT/'state/rerank_input.jsonl'
if not rr_in.exists():
    with open(rr_in,'w',encoding='utf-8') as f:
        for x in api_items:
            cs=retr[x['item_id']]
            context='\n\n'.join(f"[{c['chunk_id']}]\n{c['text']}" for c in cs)
            prompt=f"QUESTION:\n{x['question_text_vi']}\n\nCANDIDATES:\n{context}\n\nReturn exactly five chunk IDs, best first, comma-separated. Use only IDs shown."
            row={'custom_id':x['item_id'],'method':'POST','url':'/v1/responses','body':{'model':CFG['generator_model'],'instructions':'Rank evidence for Vietnamese university-admission QA. Output chunk IDs only.','input':prompt,'max_output_tokens':300,'reasoning':{'effort':'none'},'text':{'verbosity':'low'},'store':False}}
            f.write(json.dumps(row,ensure_ascii=False)+'\n')
_,rr_out=ensure_batch('rerank',rr_in,'/v1/responses');rrb=parse_batch(rr_out);usages += [('gpt',v.get('usage',{})) for v in rrb.values()]
selected={}
for x in api_items:
    valid={c['chunk_id']:c for c in retr[x['item_id']]};txt=response_text(rrb[x['item_id']]);ids=[]
    for cid in re.findall(r'[A-Za-z0-9_\-\.]+__t512_o128__c\d+',txt):
        if cid in valid and cid not in ids:ids.append(cid)
    for c in retr[x['item_id']]:
        if c['chunk_id'] not in ids:ids.append(c['chunk_id'])
    selected[x['item_id']]=[valid[i] for i in ids[:CFG['final_k']]]
jwrite(ROOT/'state/reranked_contexts.json',selected)

# Budget gate before generation based on actual embedding+rerank usage plus generation worst case.
actual=estimated_cost(usages);remaining=len(api_items)*(8000*1.25+450*7.5)/1e6
if actual+remaining>CFG['experiment_hard_ceiling_usd']:raise SystemExit(f'Budget guard stopped before generation: {actual+remaining:.4f} > 8.50')

# Stage 3: generation.
gen_in=ROOT/'state/generation_input.jsonl'
if not gen_in.exists():
    inst='''You are the controlled Hai Phong University 2026 admission assistant. Use only supplied context. Apply current field-specific source precedence. Cite every factual claim with [CHUNK_ID]. Correct false premises. Refuse forecasts, external-institution questions and unpublished values. Ask one concise clarification when necessary. Never infer a child quota from a group quota. Evaluate every condition before the first yes/no word. Answer concisely in Vietnamese.'''
    with open(gen_in,'w',encoding='utf-8') as f:
        for x in api_items:
            ctx='\n\n'.join(f"[{c['chunk_id']}] SOURCE={c['filename']} L{c['line_start']}-{c['line_end']}\n{c['text']}" for c in selected[x['item_id']])
            prompt=f"QUESTION:\n{x['question_text_vi']}\n\nCONTEXT:\n{ctx}"
            row={'custom_id':x['item_id'],'method':'POST','url':'/v1/responses','body':{'model':CFG['generator_model'],'instructions':inst,'input':prompt,'max_output_tokens':450,'reasoning':{'effort':'none'},'text':{'verbosity':'low'},'store':False}}
            f.write(json.dumps(row,ensure_ascii=False)+'\n')
_,gen_out=ensure_batch('generation',gen_in,'/v1/responses');gb=parse_batch(gen_out);usages += [('gpt',v.get('usage',{})) for v in gb.values()]
actual=estimated_cost(usages)
if actual>CFG['experiment_hard_ceiling_usd']+1e-9:raise RuntimeError(f'Actual experiment cost exceeded guard: {actual}')

# Final results and deterministic local scoring.
results=[]
for x in items:
    rt=routes[x['item_id']]
    if rt['handled']:
        ans=rt['answer'];source='C6_LOCAL';ctx=[];body=None
    else:
        body=gb[x['item_id']];ans=response_text(body);source='GPT_5_6_TERRA_BATCH';ctx=selected[x['item_id']]
    af=fold(ans);inc=sum(fold(s) in af for s in x['must_include']);den=max(1,len(x['must_include']));forbidden=sum(fold(s) in af for s in x['must_not_include'])
    results.append({'item_id':x['item_id'],'split':x['split'],'category_code':x['category_code'],'question':x['question_text_vi'],'answer':ans,'answer_source':source,'must_include_recall':inc/den,'forbidden_hits':forbidden,'retrieved_chunks':[c['chunk_id'] for c in ctx],'model':body.get('model') if body else 'deterministic-c6','usage':body.get('usage') if body else {}})
with open(ROOT/'outputs/final_results.jsonl','w',encoding='utf-8') as f:
    for r in results:f.write(json.dumps(r,ensure_ascii=False)+'\n')
summary={'status':'COMPLETE','items':len(results),'local_routed':sum(r['answer_source']=='C6_LOCAL' for r in results),'api_generated':sum(r['answer_source']!='C6_LOCAL' for r in results),'estimated_actual_batch_cost_usd':actual,'hard_ceiling_usd':CFG['experiment_hard_ceiling_usd'],'mean_must_include_recall':statistics.mean(r['must_include_recall'] for r in results),'forbidden_hits':sum(r['forbidden_hits'] for r in results),'model':CFG['generator_model']}
jwrite(ROOT/'outputs/final_summary.json',summary)
# Always package only results/state/logs, never API key.
zip_path=ROOT/'outputs/STEP4C_FINAL_RESULTS.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for folder in ['outputs','state','logs']:
        for p in (ROOT/folder).rglob('*'):
            if p.is_file() and p!=zip_path:z.write(p,p.relative_to(ROOT))
print(json.dumps(summary,ensure_ascii=False,indent=2));print('RESULT PACKAGE:',zip_path)
