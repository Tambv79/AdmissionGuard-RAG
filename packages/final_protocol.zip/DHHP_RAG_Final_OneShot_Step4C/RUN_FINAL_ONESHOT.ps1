﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
New-Item -ItemType Directory -Force -Path state,outputs,logs | Out-Null
if (-not $env:OPENAI_API_KEY) { throw "OPENAI_API_KEY is missing. No API request was sent." }
if ($env:DHHP_APPROVE_API_COST -ne "YES") { throw "Set DHHP_APPROVE_API_COST=YES. No API request was sent." }
python .\scripts\run_final.py
