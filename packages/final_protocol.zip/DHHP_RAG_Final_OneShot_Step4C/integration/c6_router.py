#!/usr/bin/env python3
"""C6 deterministic safety router for DHHP 2026 admission QA.

This module performs only high-confidence, corpus-grounded routing. It never calls an
external API. Unhandled questions are passed to the locked RAG pipeline.
"""
from __future__ import annotations
from dataclasses import dataclass
import re
import unicodedata

CIT_SCOPE = "[DHHP-2026-SCOPE]"
CIT_METHODS = "[DHHP-2026-METHODS]"
CIT_PROGRAMS = "[DHHP-2026-PROGRAMS]"
CIT_DEADLINES = "[DHHP-2026-DEADLINES]"
CIT_CERT = "[DHHP-2026-CERTIFICATES]"
CIT_TEMPORAL = "[DHHP-2026-TEMPORAL]"
CIT_TUITION = "[DHHP-2026-TUITION]"

@dataclass(frozen=True)
class RouteResult:
    handled: bool
    action: str
    answer: str = ""
    sources: tuple[str, ...] = ()


def _fold(text: str) -> str:
    text = unicodedata.normalize("NFD", text.lower().replace("đ", "d"))
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Mn")
    return re.sub(r"\s+", " ", text).strip()


def _contains(text: str, *phrases: str) -> bool:
    return any(_fold(p) in text for p in phrases)


def _external_institution(q: str) -> bool:
    allowed = ("dai hoc hai phong", "truong dai hoc hai phong", "dhhp", "hai phong university")
    if any(a in q for a in allowed):
        # A question may compare DHHP with another named institution; continue detecting.
        pass
    patterns = [
        r"(?:truong )?dai hoc ([a-z0-9\- ]{2,60})",
        r"hoc vien ([a-z0-9\- ]{2,60})",
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, q):
            tail = match.group(1).strip()
            tail = re.split(r"\b(nam|tuyen|co|la|bao nhieu|nhu the nao|nganh|diem|chi tieu)\b", tail)[0].strip()
            if tail and "hai phong" not in tail and tail not in {"chinh quy"}:
                return True
    return _contains(q, "trường khác", "truong khac", "đại học khác", "dai hoc khac")


def _extract_labelled_number(question: str, labels: tuple[str, ...]) -> float | None:
    q = question.lower()
    for label in labels:
        m = re.search(rf"{label}[^0-9]{{0,40}}(\d+(?:[\.,]\d+)?)", q)
        if m:
            return float(m.group(1).replace(',', '.'))
    return None


def _fmt(value: float) -> str:
    return f"{value:.2f}".replace('.', ',')


def route(question: str) -> RouteResult:
    q_raw = question.strip()
    q = _fold(q_raw)
    if not q:
        return RouteResult(True, "EMPTY_QUESTION", "Câu hỏi không được để trống.")

    # Scope controls.
    if _contains(q, "thạc sĩ", "sau đại học", "tiến sĩ", "cao học"):
        return RouteResult(True, "SCOPE_POSTGRADUATE",
            f"Nội dung này nằm ngoài phạm vi corpus, vốn chỉ bao gồm tuyển sinh đại học chính quy Trường Đại học Hải Phòng năm 2026. {CIT_SCOPE}",
            (CIT_SCOPE,))
    if _contains(q, "lịch học", "thời khóa biểu", "học kỳ", "lịch thi học kỳ"):
        return RouteResult(True, "SCOPE_ACADEMIC_SCHEDULE",
            f"Corpus hiện tại không bao gồm lịch học hoặc thời khóa biểu. Vui lòng liên hệ Trường để được xác nhận. {CIT_SCOPE}",
            (CIT_SCOPE,))
    if _external_institution(q):
        return RouteResult(True, "SCOPE_EXTERNAL_INSTITUTION",
            f"Corpus hiện tại chỉ bao gồm tuyển sinh đại học chính quy của Trường Đại học Hải Phòng năm 2026, nên không có căn cứ trả lời về cơ sở đào tạo khác. {CIT_SCOPE}",
            (CIT_SCOPE,))

    # Prediction and unavailable-statistic controls.
    if _contains(q, "dự đoán điểm chuẩn", "du doan diem chuan", "ước đoán điểm chuẩn", "uoc doan diem chuan"):
        return RouteResult(True, "REFUSE_CUTOFF_PREDICTION",
            f"Không thể dự đoán điểm chuẩn khi chưa có kết quả xét tuyển chính thức. Ngưỡng đầu vào không phải điểm trúng tuyển cuối cùng. {CIT_TEMPORAL}",
            (CIT_TEMPORAL,))
    if _contains(q, "chắc chắn đỗ", "chac chan do", "chắc chắn trúng tuyển", "chac chan trung tuyen"):
        return RouteResult(True, "REFUSE_ADMISSION_CERTAINTY",
            f"Không thể khẳng định chắc chắn trúng tuyển trước khi có điểm trúng tuyển và kết quả xét tuyển chính thức. {CIT_TEMPORAL}",
            (CIT_TEMPORAL,))
    if _contains(q, "bao nhiêu hồ sơ", "bao nhieu ho so", "số hồ sơ cuối đợt", "so ho so cuoi dot"):
        return RouteResult(True, "REFUSE_FUTURE_VOLUME",
            f"Nguồn hiện có không cho phép dự đoán số hồ sơ đăng ký trong tương lai. Chỉ có thể trả lời khi Nhà trường công bố số liệu chính thức. {CIT_TEMPORAL}",
            (CIT_TEMPORAL,))
    if _contains(q, "tỉ lệ chọi", "ti le choi", "tỷ lệ chọi", "ty le choi"):
        return RouteResult(True, "MISSING_COMPETITION_RATIO",
            f"Nguồn chính thức trong corpus chưa công bố tỉ lệ chọi hoặc số nguyện vọng theo ngành, nên không có căn cứ đưa ra con số. {CIT_TEMPORAL}",
            (CIT_TEMPORAL,))

    # Knowledge-base-specific missing information.
    if _contains(q, "học phí chính xác", "hoc phi chinh xac", "học phí một năm", "hoc phi mot nam") and not _contains(q, "sư phạm", "su pham", "đào tạo giáo viên", "dao tao giao vien"):
        return RouteResult(True, "MISSING_PROGRAM_TUITION",
            f"Corpus chưa công bố mức học phí cụ thể theo từng ngành, nên chưa thể cung cấp con số chính xác. Vui lòng kiểm tra thông báo học phí mới nhất hoặc liên hệ hotline 0398.171.171. {CIT_TUITION} {CIT_SCOPE}",
            (CIT_TUITION, CIT_SCOPE))
    if _contains(q, "chỉ tiêu hiện hành chính xác của riêng", "chi tieu hien hanh chinh xac cua rieng") and _contains(q, "trí tuệ nhân tạo", "tri tue nhan tao"):
        return RouteResult(True, "MISSING_CHILD_QUOTA",
            f"Nguồn hiện hành chưa công bố chỉ tiêu riêng của chương trình Trí tuệ nhân tạo và Khoa học dữ liệu; nguồn chỉ công bố tổng 135 chỉ tiêu cho nhóm Công nghệ thông tin. {CIT_PROGRAMS}",
            (CIT_PROGRAMS,))

    # Clarification controls.
    if _contains(q, "em có đủ điều kiện", "em co du dieu kien", "tôi có đủ điều kiện", "toi co du dieu kien") and not re.search(r"\d", q):
        return RouteResult(True, "CLARIFY_ELIGIBILITY",
            f"Chưa thể kết luận. Vui lòng cho biết ngành, phương thức xét tuyển, tổng điểm sau quy đổi và các điểm thành phần hoặc điều kiện cá nhân liên quan. {CIT_METHODS} {CIT_PROGRAMS}",
            (CIT_METHODS, CIT_PROGRAMS))
    if _contains(q, "chứng chỉ ngoại ngữ của em", "chung chi ngoai ngu cua em", "chứng chỉ của em", "chung chi cua em") and not re.search(r"\d", q):
        return RouteResult(True, "CLARIFY_CERTIFICATE",
            f"Chưa thể kết luận. Vui lòng cho biết loại chứng chỉ, mức điểm, số kỹ năng, hình thức thi và thời điểm đăng ký/công nhận. TOEIC phải đủ 4 kỹ năng và Home Edition không được xét. {CIT_CERT}",
            (CIT_CERT,))
    if _contains(q, "đăng ký ngành này", "dang ky nganh nay", "ngành đó đăng ký", "nganh do dang ky"):
        return RouteResult(True, "CLARIFY_PROGRAM_METHOD",
            f"Vui lòng cho biết tên hoặc mã ngành và phương thức xét tuyển dự kiến, vì hồ sơ và thời hạn khác nhau giữa PT1-PT5. {CIT_DEADLINES}",
            (CIT_DEADLINES,))

    # Structured method restrictions and exceptions.
    if _contains(q, "giáo dục thể chất", "giao duc the chat") and _contains(q, "pt2", "học bạ", "hoc ba"):
        return RouteResult(True, "RULE_PE_PT2_EXCEPTION",
            f"Có. Giáo dục Thể chất là ngoại lệ trong nhóm ngành đào tạo giáo viên và có xét PT2; thí sinh vẫn phải đáp ứng các điều kiện chung của ngành đào tạo giáo viên. {CIT_PROGRAMS} {CIT_METHODS}",
            (CIT_PROGRAMS, CIT_METHODS))

    restricted_pt2 = ("ngôn ngữ anh", "ngon ngu anh", "ngôn ngữ trung quốc", "ngon ngu trung quoc", "nhật bản học", "nhat ban hoc", "sư phạm", "su pham", "giáo dục mầm non", "giao duc mam non", "giáo dục tiểu học", "giao duc tieu hoc")
    if _contains(q, "pt2", "học bạ", "hoc ba") and any(_fold(x) in q for x in restricted_pt2) and not _contains(q, "giáo dục thể chất", "giao duc the chat"):
        return RouteResult(True, "RULE_PT2_RESTRICTION",
            f"Không. Chương trình được hỏi thuộc nhóm không xét PT2 theo quy định tuyển sinh năm 2026. {CIT_METHODS}",
            (CIT_METHODS,))

    if _contains(q, "pt4", "hsa", "tsa", "spt") and any(_fold(x) in q for x in restricted_pt2):
        return RouteResult(True, "RULE_PT4_RESTRICTION",
            f"Không. Các ngành đào tạo giáo viên, Ngôn ngữ Anh, Ngôn ngữ Trung Quốc và Nhật Bản học không xét PT4. {CIT_METHODS}",
            (CIT_METHODS,))

    # Certificate controls.
    if _contains(q, "home edition"):
        return RouteResult(True, "RULE_HOME_EDITION",
            f"Không. Chứng chỉ thi theo hình thức Home Edition không được xét trong quy định của corpus. {CIT_CERT}",
            (CIT_CERT,))
    if _contains(q, "toeic"):
        listening = _extract_labelled_number(q_raw, (r"nghe", r"listening"))
        reading = _extract_labelled_number(q_raw, (r"đọc", r"doc", r"reading"))
        speaking = _extract_labelled_number(q_raw, (r"nói", r"noi", r"speaking"))
        writing = _extract_labelled_number(q_raw, (r"viết", r"viet", r"writing"))
        if None not in (listening, reading, speaking, writing):
            ok = listening >= 275 and reading >= 275 and speaking >= 120 and writing >= 120
            decision = "Có" if ok else "Không"
            detail = "đạt" if ok else "chưa đạt"
            return RouteResult(True, "RULE_TOEIC_FOUR_SKILLS",
                f"{decision}. Bộ điểm TOEIC này {detail} mức tối thiểu: Nghe 275, Đọc 275, Nói 120 và Viết 120. {CIT_CERT}",
                (CIT_CERT,))

    # Numeric eligibility: Law.
    if _contains(q, "ngành luật", "nganh luat") and _contains(q, "toán", "toan") and _contains(q, "ngữ văn", "ngu van"):
        total = _extract_labelled_number(q_raw, (r"tổng điểm(?: xét tuyển)?", r"tong diem(?: xet tuyen)?"))
        math_score = _extract_labelled_number(q_raw, (r"điểm toán", r"diem toan", r"toán", r"toan"))
        lit_score = _extract_labelled_number(q_raw, (r"điểm ngữ văn", r"diem ngu van", r"ngữ văn", r"ngu van", r"văn", r"van"))
        if None not in (total, math_score, lit_score):
            overall = total >= 20.0
            additional = math_score >= 6 or lit_score >= 6 or (math_score + lit_score) >= 12
            if overall and additional:
                answer = f"Có. Tổng điểm {_fmt(total)} đạt ngưỡng 20,00 và thí sinh đáp ứng ít nhất một điều kiện bổ sung của ngành Luật. {CIT_PROGRAMS}"
            else:
                reasons = []
                if not overall: reasons.append(f"tổng điểm {_fmt(total)} thấp hơn 20,00")
                if not additional: reasons.append(f"Toán {_fmt(math_score)} và Ngữ văn {_fmt(lit_score)} đều dưới 6,00, đồng thời tổng hai môn {_fmt(math_score+lit_score)} thấp hơn 12,00")
                answer = f"Không. {'; '.join(reasons)}. Vì vậy thí sinh chưa đạt đầy đủ điều kiện đầu vào ngành Luật. {CIT_PROGRAMS}"
            return RouteResult(True, "RULE_LAW_NUMERIC_ELIGIBILITY", answer, (CIT_PROGRAMS,))

    # Numeric eligibility: Architecture V01.
    if _contains(q, "kiến trúc", "kien truc") and _contains(q, "v01"):
        total = _extract_labelled_number(q_raw, (r"tổng điểm(?: xét tuyển)?", r"tong diem(?: xet tuyen)?"))
        cultural = _extract_labelled_number(q_raw, (r"tổng (?:hai|2) môn văn hóa(?: cộng ưu tiên)?", r"tong (?:hai|2) mon van hoa(?: cong uu tien)?"))
        if None not in (total, cultural):
            ok = total >= 16.5 and cultural >= 11.0
            decision = "Có" if ok else "Không"
            return RouteResult(True, "RULE_ARCHITECTURE_V01",
                f"{decision}. Ngưỡng PT1 của Kiến trúc là 16,50 và với V01, tổng hai môn văn hóa cộng ưu tiên phải từ 11,00. Dữ liệu đã cung cấp: tổng điểm {_fmt(total)}, phần văn hóa cộng ưu tiên {_fmt(cultural)}. {CIT_PROGRAMS}",
                (CIT_PROGRAMS,))

    return RouteResult(False, "PASS_TO_RAG")


def normalize_generated_answer(question: str, answer: str) -> str:
    """Remove an unsupported leading affirmative from non-polar information questions."""
    q = _fold(question)
    a = answer.strip()
    polar = ("co duoc", "co the", "co dat", "dung khong", "co chac chan", "duoc huong", "co xet")
    if (a.startswith("Có,") or a.startswith("Có.")) and not any(x in q for x in polar):
        return a[3:].lstrip()
    return a
