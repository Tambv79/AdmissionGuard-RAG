# DHHP RAG Final One-Shot TEST/STRESS Experiment — Step 4C

Status: READY_FOR_USER_EXECUTION_AFTER_MODEL_PERMISSION_UPDATE

## Locked model
- Generator and reranker: `gpt-5.6-terra`
- Embedding: `text-embedding-3-large`
- Do **not** use `gpt-5.5`. It is twice the Terra token price and would violate the scientific model lock used in DEV.

## Budget safety
- Experiment hard ceiling: **USD 8.50**
- Worst-case all 300 tasks under locked token caps: **USD 7.6925**
- Deterministic C6 routes in this benchmark: **48/300**
- Planned API tasks: **252/300**
- Planned worst-case cap after routing: **USD 6.4617**
- Batch API only; no synchronous paid calls.
- Before each paid stage, the script combines actual completed-stage usage with worst-case remaining cost and aborts if the total can exceed USD 8.50.
- Completed Batch IDs and output files are checkpointed; rerunning resumes and never resubmits a completed stage.

## Required platform settings before execution
1. Project Settings > Limits > Model usage > Edit.
2. Add `gpt-5.6-terra` and `text-embedding-3-large`. Keeping GPT-5.5 allowed is optional; this package never uses it.
3. Current August spend shown by the researcher: USD 4.22. To cap additional spending below USD 8.50, set the project **hard monthly limit to USD 12.70**, not USD 8.50. Select hard enforcement if the UI offers soft versus hard behavior.
4. Add alerts at 80%, 90%, and 100%.

## Run one command
Open PowerShell in this folder:

```powershell
$env:OPENAI_API_KEY="YOUR_KEY"; $env:DHHP_APPROVE_API_COST="YES"; powershell -ExecutionPolicy Bypass -File .\RUN_FINAL_ONESHOT.ps1
```

The Batch API may take up to 24 hours per stage. Keep the folder unchanged. Running the same command again resumes from saved batch IDs.

## Return only
`outputs\STEP4C_FINAL_RESULTS.zip`

Never send the API key.

## Benchmark provenance
The 240 TEST and 60 STRESS tasks are deterministically generated from the locked official structured corpus. No model output was used to create gold answers. This package does not claim independent human review of the final 300 tasks.
